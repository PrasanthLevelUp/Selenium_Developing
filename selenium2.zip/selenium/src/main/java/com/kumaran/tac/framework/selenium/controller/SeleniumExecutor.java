package com.kumaran.tac.framework.selenium.controller;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ExpressionResult;
import com.kumaran.tac.common.dto.FailureDetail;
import com.kumaran.tac.common.dto.FieldDetail;
import com.kumaran.tac.common.dto.TestStep;
import com.kumaran.tac.common.dto.TestStepData;
import com.kumaran.tac.common.dto.Transaction;
import com.kumaran.tac.common.enums.ActionOnValidationFailure;
import com.kumaran.tac.common.enums.ValidationType;
import com.kumaran.tac.common.exception.RetryStepException;
import com.kumaran.tac.common.exception.TACException;
import com.kumaran.tac.common.util.AutowireHelperUtil;
import com.kumaran.tac.framework.common.client.AgentClient;
import com.kumaran.tac.framework.common.executor.Executor;
import com.kumaran.tac.framework.common.util.FrameworkConstants;
import com.kumaran.tac.framework.common.util.FrameworkUtility;
import com.kumaran.tac.framework.common.validation.IValidation;
import com.kumaran.tac.framework.selenium.frameworklayer.BrowserControls;
import com.kumaran.tac.framework.selenium.frameworklayer.PageObjectHandler;
import com.kumaran.tac.framework.selenium.frameworklayer.SeleniumUtility;
import com.kumaran.tac.framework.selenium.validation.ContentValidation;
import com.kumaran.tac.framework.selenium.validation.DetermineLanguageValidation;
import com.kumaran.tac.framework.selenium.validation.EditableValidation;
import com.kumaran.tac.framework.selenium.validation.ErrorMessageValidation;
import com.kumaran.tac.framework.selenium.validation.PopupMessageValidation;
import com.kumaran.tac.framework.selenium.validation.TableValidation;
import com.kumaran.tac.framework.selenium.validation.TextValidation;
import com.kumaran.tac.framework.selenium.validation.ToolTipMessageValidation;
import com.kumaran.tac.framework.selenium.validation.VisiblityValidation;

@Component
public class SeleniumExecutor extends Executor {
	
	@Autowired
	BrowserControls browserControls;
	
	@Autowired
	SeleniumController seleniumController;
	
	@Autowired
	SeleniumUtility seleniumUtility;
	
	@Autowired
	AgentClient agentClient;
	
	@Autowired
	PageObjectHandler pageObjectHandler;
	
	@Autowired
	VisiblityValidation visiblityValidation;
	
	@Autowired
	ContentValidation contentValidation;
	
	@Autowired
	EditableValidation editableValidation;
	
	@Autowired
	DetermineLanguageValidation determineLanguageValidation;
	
	@Autowired
	ErrorMessageValidation errorMessageValidation;
	
	@Autowired
	PopupMessageValidation popupMessageValidation;
	
	@Autowired
	TableValidation tableValidation;
	
	@Autowired
	TextValidation textValidation;
	
	@Autowired
	ToolTipMessageValidation toolTipMessageValidation;
	

	private String browserControl = null;
	
	private String browser;
	
	private Map<Integer, List<FieldDetail>> frameMap;
	
	private List<Map<String, Object>> fieldIdentificationAtrr = null;
	
	private String transactionColumnName = "";
	
	private Long reEntryInd;
	
	private String languageVariable = "tac_aut_language";
	
	private String languageTACAUT = "English";
	
	private Map<String, Map<String, String>> projectLevelTranslations = null;
	
	private Map<String, Map<String, String>> transactionLevelTranslations = null;
	
	private List<Attribute> attributes = null;
	
	protected List <Attribute> tacPageTitle;
	
	protected List <Attribute> tacHasAppErrors;
	
	protected List <Attribute> tacAppErrorMessages;
	
	protected List <Attribute> tacIsUnhandledError;
	
	protected List <Attribute> tacUnhandledErrorMessages;
	
	private Integer attributeMaxWait = 0;
	
	private Attribute currentAttribute = new Attribute();
	
	private List<String> errorMessages;
	
	List<Map<String, Object>> readMrbFromMap = new ArrayList<>();
	
	private Integer mrbpId = 0;
	
	private String mrbGridType;
	
	private Integer frameAttributeId = 1;
	
	private Integer multiElement = 0;
	
	public String getBrowserControl() {
		return browserControl;
	}

	public void setBrowserControl(String browserControl) {
		this.browserControl = browserControl;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}
	
	public Map<Integer, List<FieldDetail>> getFrameMap() {
		return frameMap;
	}

	public void setFrameMap(Map<Integer, List<FieldDetail>> frameMap) {
		this.frameMap = frameMap;
	}
	
	public List<Map<String, Object>> getFieldIdentificationAtrr() {
		return fieldIdentificationAtrr;
	}

	public void setFieldIdentificationAtrr(List<Map<String, Object>> fieldIdentificationAtrr) {
		this.fieldIdentificationAtrr = fieldIdentificationAtrr;
	}
	
	public String getLanguageTACAUT() {
		return languageTACAUT;
	}

	public void setLanguageTACAUT(String languageTACAUT) {
		this.languageTACAUT = languageTACAUT;
	}
	
	public Integer getFrameAttributeId() {
		return frameAttributeId;
	}

	public void setFrameAttributeId(Integer frameAttributeId) {
		this.frameAttributeId = frameAttributeId;
	}
	
	public List<Attribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<Attribute> attributes) {
		this.attributes = attributes;
	}
	
	public List<String> getErrorMessages() {
		return errorMessages;
	}

	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	
	public Integer getMultiElement() {
		return multiElement;
	}
	
	public void setMultiElement( Integer element) {
		multiElement = element;
	}

	public String getTransactionColumnName() {
		return transactionColumnName;
	}

	public void setTransactionColumnName(String transactionColumnName) {
		this.transactionColumnName = transactionColumnName;
	}
	
	public Integer getMrbpId() {
		return mrbpId;
	}

	public void setMrbpId(Integer mrbpId) {
		this.mrbpId = mrbpId;
	}

	public String getMrbGridType() {
		return mrbGridType;
	}

	public void setMrbGridType(String mrbGridType) {
		this.mrbGridType = mrbGridType;
	}
	
	public Integer getAttributeMaxWait() {
		return attributeMaxWait;
	}

	public void setAttributeMaxWait(Integer attributeMaxWait) {
		this.attributeMaxWait = attributeMaxWait;
	}

	public Attribute getCurrentAttribute() {
		return currentAttribute;
	}

	public void setCurrentAttribute(Attribute currentAttribute) {
		this.currentAttribute = currentAttribute;
	}

	public void loadCustomAttributesClass( String methodName) {
		try {
			Class<?> ca = loadClass( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES);
			if (ca != null) {
				Object objca = ca.newInstance();
				if( methodName != null) {
					Method cam = ca.getMethod( methodName);
					if (cam != null) {
						if( methodName.equals( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_START_TIME)) {
							setStartTime( (String) cam.invoke(objca));
						} else if( methodName.equals( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_COMPLETED_TIME)) {
							setCompletedTime( (String) cam.invoke(objca));
						}
					}											
				}
			}
		} catch ( Exception e) {
			logger.error( "Exception Error occurred while loading custom attribute class : {}", e.getMessage());
			if( methodName != null) {
				if( methodName.equals( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_START_TIME)) {
					setStartTime( FrameworkUtility.startTime());					
				} else if( methodName.equals( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_COMPLETED_TIME)) {
					setCompletedTime( FrameworkUtility.completedTime());
				}
			}
		}
	}
	
	private void loadCustomValidationClass( String methodName) {
		try {
			Class<?> ca = loadClass( FrameworkConstants.CLASS_CUSTOM_VALIDATION);
			if (ca != null) {
				Object objcv = ca.newInstance();
				Method cvm = ca.getMethod( methodName);
				if (cvm != null) {
					cvm.invoke(objcv);
				}
			}
		} catch (ClassNotFoundException e) {
			if( methodName != null) {
				currentPageValidation();				
			}
		} catch ( Exception e) {
			logger.error( "Error occurred while loading customValidationClass", e);
		}
	}
	
	private Class<?> loadClass( String className) throws ClassNotFoundException   {
		Class<?> classObject = Class.forName( className);
		if (classObject != null) {
			logger.info("CLASS ADDED : {}", className);
		}
		return classObject;
	}
	
	@Override
	public void init() {
		loadCustomValidationClass( null);
		loadCustomAttributesClass( null);
	}

	@Override
	public ExecutorAction processsMessageCommand(String command) throws Exception {
		ExecutorAction operation = ExecutorAction.PROCEED;
		if ( command.contains( FrameworkConstants.COMMAND_TEST_RUN_COMPLETED) 
				|| command.contains( FrameworkConstants.COMMAND_TEST_RUN_ABORTED)) {
			if (browserControls.getDriver() != null) {
				browserControls.closeBrowser(browser);
			}
			logger.info( "[Exit] Exiting process as Test run completed / Aborted flag triggered.");
			operation = ExecutorAction.TERMINATE;
		} else if ( command.contains("testcaseEnd") && browserControl != null && browserControl.equals("tc")) {
			browserControls.closeBrowser(browser);
			Thread.sleep(5000);
			browserControls.setDriver( null);
		}
		return operation;
	}
	
	@Override
	public void extractTestStep(TestStep testStep) throws Exception {
		browserControl = getExecutionPlan().getBrowserControl();
		seleniumUtility.setApplicationURL( getOrJson().getUrl());
		if (getOrJson().getBrowser() != null) {
			browser = getOrJson().getBrowser();
		}
		if (browserControls.getDriver() == null) {
			openBrowserOrAbort();
		}
		AutowireHelperUtil.getBeanObj( Verification.class).setDVMapPassStatus( new HashMap<>());
	}
	
	private void openBrowserOrAbort() throws Exception {
		try {
			browserControls.openBrowser(browser);
		} catch (Exception e) {
			logger.error( "Unable to open browser. Aborting the test run.");
			abortOnApplicationException( "Browser",  "Error occured while invoking the browser");
			throw e;
		}
	}
	
	@Override
	public void populateFinalStepResponse(String status, FailureDetail failureDetail) {
		loadCustomAttributesClass( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_COMPLETED_TIME);
		
		try {
			Verification verification = AutowireHelperUtil.getBeanObj( Verification.class);
			logger.info("DataVerification Value Now : {}" , verification.getDataVerification());
			if (verification.getDataVerification() != null && !verification.getDVMapPassStatus().isEmpty()) {
				getFrameworkStepResponse().setVerificationStatus(
						verification.getDVMapPassStatus().get( FrameworkConstants.RESPONSE_VERIFICATION_STATUS).toString());
			}
		} catch (Exception e) {
			logger.error("Error getting instnace of Verification", e);
		}
	}
	
	@Override
	public String getFrameworkCode() {
		return FrameworkConstants.FRAMEWORK_CODE_SELENIUM;
	}
	
	@Override
	public void extractTestStepData(TestStepData testStepData) throws Exception {
		frameMap = new HashMap<>();
		fieldIdentificationAtrr = testStepData.getFieldIdentificationAtrr();
		reEntryInd = testStepData.getReEntryInd();
		transactionColumnName = "";
		if( getParameters().containsKey(languageVariable) && getParameters().get(languageVariable) != null) {
			languageTACAUT = getParameters().get(languageVariable);
		}
		loadCustomValidationClass(  FrameworkConstants.CLASS_CUSTOM_VALIDATION_METHOD_CURRENT_PAGE_VALIDATION);
		currentPageValidation();
	}
	
	@Override
	public void extractTranslationAndStandardAttributes( Transaction transaction) {
		setTransactionName( transaction.getTransactionName());
		projectLevelTranslations = transaction.getProjectLevelTranslations();
		transactionLevelTranslations = transaction.getTransactionLevelTranslations();
		formStandardAttributes(transaction);
		attributes = transaction.getAttributes();
	}
	
	public void formStandardAttributes(Transaction transaction) {
		tacPageTitle = new ArrayList<>();
		tacHasAppErrors = new ArrayList<>();
		tacAppErrorMessages = new ArrayList<>();
		tacIsUnhandledError = new ArrayList<>();
		tacUnhandledErrorMessages = new ArrayList<>();
		processStandardAttributes( transaction.getTransactionLevelStandardAttributes(), false);
		processStandardAttributes( transaction.getProjectLevelStandardAttributes(), true);
	}
	
	private void processStandardAttributes( List< Attribute> attributes, boolean isProjectLevel) {
		for(Attribute obj: attributes) {
			if (obj.getName().equals( FrameworkConstants.TAC_PAGE_TITLE) && ( !isProjectLevel || tacPageTitle.isEmpty())) {
				tacPageTitle.add(obj);
			} else if (obj.getName().equals( FrameworkConstants.TAC_HAS_APP_ERRORS) && ( !isProjectLevel || tacHasAppErrors.isEmpty())) {
				tacHasAppErrors.add(obj);
			} else if (obj.getName().equals( FrameworkConstants.TAC_APP_ERROR_MESSAGES) && ( !isProjectLevel || tacAppErrorMessages.isEmpty())) {
				tacAppErrorMessages.add(obj);
			} else if (obj.getName().equals( FrameworkConstants.TAC_IS_UNHANDLED_ERROR) && ( !isProjectLevel || tacIsUnhandledError.isEmpty())) {
				tacIsUnhandledError.add(obj);
			} else if (obj.getName().equals( FrameworkConstants.TAC_UNHANDLED_ERROR_MESSAGES) && ( !isProjectLevel || 
					tacUnhandledErrorMessages.isEmpty())) {
				tacUnhandledErrorMessages.add(obj);
			}
		}
	}
	
	public void performPostValidationEntry( Transaction transaction, List<Map<String, Object>> attributeJsonList) {
		List<Attribute> entry = transaction.getEntry();
		Map<String, Object> attributeJson = null;
		logger.info("Transaction entry size : {}" , entry.size());
		if ( !entry.isEmpty()) {
			logger.info("Entry attribute id {}" , entry.get(0).getId());
			for (int j = 0; j < entry.size(); j++) {
				logger.info("Post Validation  Entry");
				Attribute entryAttr = entry.get(j);
				attributeMaxWait = entryAttr.getMaxWait();
				attributeJson = attributeJsonList.get(0);
				Integer attributeId = entryAttr.getId();
				String testData = attributeJson.get(String.valueOf(attributeId)) == null ? ""
						: attributeJson.get(String.valueOf(attributeId)).toString();
				try {							
					pageObjectHandler.dataFeed(testData, entryAttr, entryAttr.getWindowOrFrame());
				} catch(StaleElementReferenceException e) {
					pageObjectHandler.dataFeed(testData, entryAttr, entryAttr.getWindowOrFrame());
				}
				attributeMaxWait = 0;
			}
		}

	}
	
	public void performPageTitleValidation( Transaction transaction) {
		logger.info("Browser title : {}", browserControls.getDriver().getTitle());
		if (transaction.getPageTitle() != null && !transaction.getPageTitle().isEmpty()) {
			String title = transaction.getPageTitle();
			String actualTitle = null;
			for(Attribute attribute : tacPageTitle) {
				WebElement webElement = null;
				try {								
					webElement = pageObjectHandler.findObject(attribute.getFieldDetails());
				} catch(Exception e) {
					continue;
				}
				actualTitle = webElement.getText();
			}
			if(tacPageTitle.isEmpty() || actualTitle == null) {							
				actualTitle = browserControls.getDriver().getTitle();
			}
			compareTitles(title, actualTitle, transaction.getPartialTitleInd() == 1);
		}
	}
	
	private void compareTitles( String title, String actualTitle, boolean isPartialTitle) {
		String failureMessage = "title("+title+") does not match- "+actualTitle;
		if( ( isPartialTitle && !actualTitle.contains(title)) ||  !actualTitle.equals(title)) {
			logger.error( "{} {}", isPartialTitle ? "Partial" :"" , failureMessage);
			getFailureDetail().updateFailureDetails(null, null, failureMessage, FrameworkConstants.MESSAGE_CODE_STANDARD, 
					getTransactionStepId());
			if(!isContinueOnFailure()){									
				throw new TACException( FrameworkConstants.EXCEPTION_TEST_FAIL);
			}
		}
	}
	
	public void performBuiltInValidations(Transaction transaction) {
		errorMessages = new ArrayList<>();
		if ( !tacHasAppErrors.isEmpty()) {			
			gatherErrorMessages(tacHasAppErrors);
		}
		if ( !tacAppErrorMessages.isEmpty()) {					
			gatherErrorMessages(tacAppErrorMessages);
		}
		if ( !tacIsUnhandledError.isEmpty()) {					
			gatherErrorMessages(tacIsUnhandledError);
		}
		if ( !tacUnhandledErrorMessages.isEmpty()) {					
			gatherErrorMessages(tacUnhandledErrorMessages);
		}
	}

	private void gatherErrorMessages(List<Attribute> attributeList) {
		for( Attribute attr :attributeList) {
			if(attr.getEnabledInd() == 1) {
				List<WebElement> elementList = pageObjectHandler.findAllObjects(attr.getFieldDetails());
				elementList.stream().filter( Objects::nonNull).map( WebElement::getText).filter( Objects::nonNull)
					.filter( ((Predicate<String>) String::isEmpty).negate()).forEach( errorMsg -> errorMessages.add(errorMsg));
			}
		}
	}
	
	@Override
	public ExecutorAction performFrameworkOperation( Transaction transaction, TestStepData testStepData, 
			List<Map<String, Object>> attributeJson, int i, int testDataSize) throws RetryStepException, Exception {
		for( int a = 0; a < testDataSize; a++) {
			boolean isParent = false;
			Map<String, Object> singleTestData = attributeJson.get(a);
			performPostValidationEntry(transaction, attributeJson);
			extractValidtions( singleTestData);
			performPageTitleValidation(transaction);
			performBuiltInValidations(transaction);
			extractPositionValidations();
			if( getEntryValidations() != null && getEntryValidations().length > 0) {
				performValidation( getEntryValidations(), i, FrameworkConstants.VALIDATION_POSITION_ENTRY, null);				
			}
			if ( getActionOnFailure().equals( ActionOnValidationFailure.DO_NOT_FAIL_TESTCASE)) {
				for (int j = 0; j < attributes.size(); j++) {
					Attribute attrs = this.attributes.get(j);
					currentAttribute = this.attributes.get(j);
					attributeMaxWait = attrs.getMaxWait();
					if( attrs.getRead_only() != null && attrs.getRead_only() == 1) {
						continue;
					}
					int attributeId = attrs.getId();
					int parentAttributeId = attrs.getParentAttrId();
					if( getBeforeValidations() != null && getBeforePositionIds().contains(attributeId)) {
						performValidation( getBeforeValidations(), i, FrameworkConstants.VALIDATION_POSITION_BEFORE, attributeId);
					}
					String mrbgrid = attrs.getType();
					if (mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME)) {
						frameMap.put(Integer.valueOf(attributeId), attrs.getFieldDetails());
					}
					if (parentAttributeId == 0 && !mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID) && !isParent
							&& !mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME) 
							&& !mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_WINDOW_DIALOG)) {
						seleniumUtility.transactionDataHandle(attrs, singleTestData);
					}
					if (parentAttributeId == 0 && attrs.getType().equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)
							|| attrs.getType().equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME)
							|| attrs.getType().equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_WINDOW_DIALOG) && !isParent) {
						attributeId =attrs.getId();
						readMrbFromMap = (List<Map<String, Object>>) singleTestData.get(String.valueOf(attributeId));
						logger.info("MRB content : {}", readMrbFromMap);
						isParent = true;
						doContainerAttributeAction( i, j, attrs);
					}
					if ( isParent && !getOrJson().getTransactions().get(i).getAttributes().get(j).getType()
							.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)) {
						isParent = false;
						continue;
					}
					
					performAfterAndEOAValidations(i, j, transaction, attrs);
					populateErrorMessages(j, transaction, attrs);
				}
				attributeMaxWait = 0;
				performPostValidationReEntry(transaction);
				if ( getAfterReEntryValidations() != null) {
					try{
						performValidation( getAfterReEntryValidations(), i, FrameworkConstants.VALIDATION_POSITION_AFTER_REENTRY, null);
					} catch ( NullPointerException e) {
						setAfterReEntryValidations( null);
					}
				}
				/********************
				 * Below Entry code copied to make the Entry from next
				 * transaction
				 ***********************/
				if (a == testDataSize - 1) {
					return ExecutorAction.TERMINATE;
				}
			}
		}
		return ExecutorAction.PROCEED;
	}
	
	private void performPostValidationReEntry( Transaction transaction) throws Exception {
		try {
			logger.info("Post Validation Re Entry");
			List<Attribute> reentry = null;
			if(reEntryInd.intValue()==1) {
				reentry = transaction.getEntry();
			} else {								
				reentry = transaction.getReEntry();
			}
			logger.info("Reentry validation size : {}" , reentry.size());
			if ( !reentry.isEmpty()) {
//						for (int j = 0; j < reentry.size(); j++) {
//							logger.info("Post Validation Re Entry");
//							Attribute reEntryAttr = reentry.get(j);
//
//							logger.info("Post Validation Re Entry");
//							attributeMaxWait = reEntryAttr.getMaxWait();
//							attributeJson = arrtibuteJson.get(0);
//							Integer attributeId = reEntryAttr.getId();
//							String testData = attributeJson.get(String.valueOf(attributeId)) == null ? ""
//									: attributeJson.get(String.valueOf(attributeId)).toString();
//							try {										
//								pageObjectHandler.datafeed(testData, reEntryAttr, reEntryAttr.getWindowOrFrame());
//							} catch(StaleElementReferenceException e) {
//								Selenide.refresh();
//								pageObjectHandler.datafeed(testData, reEntryAttr, reEntryAttr.getWindowOrFrame());
//							}
//							attributeMaxWait = 0;
//						}
//						Verification.DataVerificationFromMaptoAppliaction(testDataJson, i);
				Verification verification = AutowireHelperUtil.getBeanObj( Verification.class);
				verification.setDataVerification( "");
			}
		} catch (Exception e) {
			logger.error( "Error occurred : " , e);
			if(e.getMessage().equals( FrameworkConstants.EXCEPTION_TEST_FAIL)) {
				throw e;
			}
		}
	}
	
	private void doContainerAttributeAction( int transactionIndex, int j, Attribute attribute) throws Exception {
		String mrbgrid = attribute.getType();
		int attributeId = attribute.getId();
		List<FieldDetail> mrbFieldDeatils = attribute.getFieldDetails();
		for (int mrbcount = 0; mrbcount < readMrbFromMap.size(); mrbcount++) {
			Map<String, Object> readListOfMrbs = readMrbFromMap.get(mrbcount);
			seleniumUtility.setTableLookupRowData( "");
			seleniumUtility.setColumnNames( new ArrayList<>());
			for (int l = j; l < this.attributes.size(); l++) {
				Attribute mrbAttributes = this.attributes.get(l);
				mrbpId = mrbAttributes.getParentAttrId();
				String subMrebssNew = mrbAttributes.getType();
				mrbGridType = attribute.getGridType();
				if (mrbpId == attributeId && mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_WINDOW_DIALOG)) {
					seleniumUtility.mrbTransactionDataHandle(mrbAttributes, readListOfMrbs, mrbFieldDeatils);
				}
				if (mrbpId == attributeId && mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME)) {
					seleniumUtility.mrbTransactionDataHandle(mrbAttributes, readListOfMrbs, mrbFieldDeatils);
				}
				if (mrbpId == attributeId && mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)
						&& !subMrebssNew.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)) {
					seleniumUtility.mrbTransactionDataHandle(mrbAttributes, readListOfMrbs, mrbFieldDeatils);
				} else if (mrbpId == attributeId && subMrebssNew.equalsIgnoreCase("grid")) {
					int subsubreb = mrbAttributes.getId();
					List<FieldDetail> subMrbFieldDeatils = mrbAttributes.getFieldDetails();
					List<Map<String, Object>> readSubMrb = (List<Map<String, Object>>) readListOfMrbs.get(String.valueOf(subsubreb));
					logger.info("Sub mrabs data size : {}" , readSubMrb);
					for (int subMrbCount = 0; subMrbCount < readSubMrb.size(); subMrbCount++) {
						Map<String, Object> getSubMrbData = readSubMrb.get(subMrbCount);
						seleniumUtility.setTableLookupRowData( "");
						seleniumUtility.setColumnNames( new ArrayList<>());
						for (int m = l; m < this.attributes.size(); m++) {
							Transaction subMebTransactions = getOrJson().getTransactions().get(transactionIndex);
							Attribute subMebAttributes = subMebTransactions.getAttributes()
									.get(m);
							int subPid = subMebAttributes.getParentAttrId();
							String subMrebssnew2 = subMebAttributes.getType();
							if (subPid == subsubreb
									&& !subMrebssnew2.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)) {
								seleniumUtility.mrbTransactionDataHandle(subMebAttributes, getSubMrbData, subMrbFieldDeatils);
							}
						}
					}
				}
			}
		}
	}
	
	private void performAfterAndEOAValidations( int transactionIndex, int attributeIndex, Transaction transaction, Attribute attrs) 
			throws Exception {
		performBuiltInValidations(transaction);
		if( getAfterValidations() != null && getAfterPositionIds().contains( attrs.getId())) {
			performValidation( getAfterValidations(), transactionIndex, FrameworkConstants.VALIDATION_POSITION_AFTER, attrs.getId());
		}
		if((( attrs.getEndTransactionFlag() != null && attrs.getEndTransactionFlag().booleanValue())
				|| attributes.size() == attributeIndex+1) && getEoaValidations() != null) {
			performValidation( getEoaValidations(), transactionIndex, FrameworkConstants.VALIDATION_POSITION_END_OF_ATTRIBUTE, null);
		}
	}
	
	private void populateErrorMessages( int attributeIndex, Transaction transaction, Attribute attrs) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		if( !errorMessages.isEmpty()) {
			getFailureDetail().updateFailureDetails(currentAttribute.getId(), 
					currentAttribute.getName(), "application error occured- "+ mapper.writeValueAsString(errorMessages), 
					FrameworkConstants.MESSAGE_CODE_STANDARD, getTransactionStepId());
			if(!isContinueOnFailure()) {
				throw new TACException( FrameworkConstants.EXCEPTION_TEST_FAIL);
			}
		}
		if( ( attrs.getEndTransactionFlag() != null && attrs.getEndTransactionFlag().booleanValue())
				|| attributes.size() != attributeIndex+1) {
			performBuiltInValidations(transaction);
		}
	}
	
	public void populateValidationErrorDetails( String position) {
		String attributeName = "";
		int id = 0;
		if( !position.equals(FrameworkConstants.VALIDATION_POSITION_ENTRY)) {
			attributeName = currentAttribute != null ? currentAttribute.getName() : "";
			id = currentAttribute != null ? currentAttribute.getId() : 0;				
		}
		getFailureDetail().updateFailureDetails( id, attributeName, "Validation Status failed", FrameworkConstants.MESSAGE_CODE_VALIDATION,
				getTransactionStepId());
	}
	
	public String getTranslatedValue(String testData, Map<String, String> translation) {
		if(translation.containsKey(testData)) {
			return translation.get(testData);
		}
		return null;
	}
	
	public String translateTestData( String testData) {
		String tempData = null;
		if(transactionLevelTranslations != null && transactionLevelTranslations.containsKey(languageTACAUT)){
			tempData = getTranslatedValue(testData,transactionLevelTranslations.get(languageTACAUT));
			if(tempData != null) {
				return tempData;
			}
		} 
		if (projectLevelTranslations != null && projectLevelTranslations.containsKey(languageTACAUT)) {
			tempData = getTranslatedValue(testData,projectLevelTranslations.get(languageTACAUT));
			if(tempData != null) {
				return tempData;
			}
		}
		return testData;
	}
	
	
	public String getFieldIdentificationAtrrVal(Integer attributeId) {
		String idValue = null;
		if(fieldIdentificationAtrr != null && !fieldIdentificationAtrr.isEmpty()) {
			Optional< String> optional = fieldIdentificationAtrr.stream().filter( e -> e.containsKey( attributeId.toString()))
					.map( e -> e.get( attributeId.toString()).toString()).findFirst();
			if( optional.isPresent()) {
				idValue = optional.get();
				if(idValue.contains("$")) {
					 ExpressionResult expRes = agentClient.getExpressionValue(idValue);
					 idValue = expRes.getOutput();
					 if( expRes.hasError()) {
						 pageObjectHandler.setFailureReason( expRes.getErrorMessage());
					 }
				}
			}
		}
		return idValue; 
	}
	
	@SuppressWarnings("rawtypes")
	public void currentPageValidation() {
		String value = null;
		Document doc1 = null;
		String htmltext = null;
		Map<String, Object> currentPageValidation = getOrJson().getProjectValidation();
		Iterator validatorItr = currentPageValidation.entrySet().iterator();
		while (validatorItr.hasNext()) {
			Map.Entry validationPair = (Map.Entry) validatorItr.next();
			value = validationPair.getValue().toString();
			try {
				browserControls.getDriver().getPageSource();
				doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
			} catch (UnhandledAlertException e) {
				doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
			}
			catch (NullPointerException e) {
				logger.error("Null in Page source : {}", e.getMessage());
			}
			htmltext = doc1.select("html").text();
			logger.info( "Status : {} ", htmltext.contains(value) ? "Fail" : "Pass");
		}
	}
	
	@Override
	public Map<ValidationType, IValidation> getValidators() {
		Map< ValidationType, IValidation> ret = new EnumMap<>( ValidationType.class);
		ret.put( ValidationType.CONTENT, contentValidation);
		ret.put( ValidationType.EDITABILITY, editableValidation);
		ret.put( ValidationType.POPUPMESSAGE, popupMessageValidation);
		ret.put( ValidationType.TEXT, textValidation);
		ret.put( ValidationType.TOOLTIPMESSAGE, toolTipMessageValidation);
		ret.put( ValidationType.VISIBILITY, visiblityValidation);
		ret.put( ValidationType.TABLE, tableValidation);
		ret.put( ValidationType.DETERMINELANGUAGE, determineLanguageValidation);
		ret.put( ValidationType.ERRORMESSAGE, errorMessageValidation);
		return ret;
	}
}
