package com.kumaran.tac.framework.selenium.validation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.model.ValidationModel;

@Component
public class TableValidation extends BaseValidation {

	@Override
	public boolean isAttributeBasedValidation() {
		return true;
	}

	@Override
	public boolean isImplicitValidation() {
		return false;
	}

	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}

	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		ValidationRequestWrapper wrapper = new ValidationRequestWrapper();
		WebElement table = getWebElement( attribute.getFieldDetails());
		List<WebElement> tr = table.findElements(By.tagName("tr"));
		wrapper.getValidationRequest().setColumnHeading( validationModel.getColumnHeading());
		int rownum = 0;
		int columPos = 0;
		try {
			rownum = Integer.valueOf( validationModel.getRowNumber());
		} catch (NumberFormatException e) {
			// Ignoring exception.
		}
		StringBuilder nameBuilder = new StringBuilder();
		if (!validationModel.getColumnHeading().contains(",")) {
			List<WebElement> th = tr.get(0).findElements(By.tagName("th"));
			for (int i = 0; i < th.size(); i++) {
				String columName = th.get(i).getText();
				nameBuilder.append( th.get(i).getText());
				if ( validationModel.getColumnHeading().equalsIgnoreCase(columName)) {
					columPos = i;
					break;
				}
			}
			if (!nameBuilder.toString().contains( validationModel.getColumnHeading())) {
				logger.info("Column not present");
			}
		} 
		if (rownum > 0) {
			List<WebElement> td = tr.get(rownum).findElements(By.tagName("td"));
			String actColumnData = td.get(columPos).getText();
			wrapper.getValidationRequest().setActColumnData(actColumnData);
		}
		return wrapper;
	}

}
