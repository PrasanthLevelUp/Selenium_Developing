package com.kumaran.tac.framework.selenium.validation;

import java.util.List;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.FieldDetail;
import com.kumaran.tac.common.dto.FrameworkValidationEntity;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.model.ValidationModel;
import com.kumaran.tac.framework.common.validation.IValidation;
import com.kumaran.tac.framework.selenium.controller.SeleniumExecutor;
import com.kumaran.tac.framework.selenium.frameworklayer.PageObjectHandler;
import com.kumaran.tac.framework.selenium.frameworklayer.SwitchContainer;

public abstract class BaseValidation implements IValidation {
	
	@Autowired
	SeleniumExecutor seleniumExecutor;
	
	@Autowired
	PageObjectHandler pageObjectHandler;
	
	public static final Logger logger = LoggerFactory.getLogger( BaseValidation.class);

	public abstract ValidationRequestWrapper executeInternal( ValidationModel validationModel, Attribute attribute) throws Exception;
	
	@Override
	public ValidationRequestWrapper execute(ValidationModel validationModel, Attribute attribute) throws Exception {
		SwitchContainer switchToContainer = new SwitchContainer( attribute.getWindowOrFrame());
		switchToContainer.giveControl();
		ValidationRequestWrapper ret = null;
		try {
			ret = executeInternal(validationModel, attribute);			
		} catch( WebDriverException e) {
			logger.debug( "Selenium expection while performing validation. Validation / Step will retry, if provided.", e);
			ret = new ValidationRequestWrapper();
			ret.addActual( "");
		}
		switchToContainer.takeBackControl();
		return ret;
	}
	
	protected final WebElement getWebElement( List<FieldDetail> fieldDetails) {
		return pageObjectHandler.findObject( fieldDetails);
	}
	
	protected final void updateParameterValue( String parameter, String value) {
		if( parameter != null) {
			seleniumExecutor.getParameters().put( parameter, value);
		}
	}
	
	public void postValidation(ValidationModel validationModel, Attribute attributes, FrameworkValidationEntity validationResponse) {	
		logger.debug( "No post validation action defined for {}.", this.getClass().getName());
	}
}
