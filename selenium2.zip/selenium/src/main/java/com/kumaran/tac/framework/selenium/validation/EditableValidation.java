package com.kumaran.tac.framework.selenium.validation;

import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.enums.ValidationComparisonType;
import com.kumaran.tac.common.model.ValidationModel;
import com.kumaran.tac.framework.common.util.FrameworkConstants;

@Component
public class EditableValidation extends BaseValidation {
	
	private static final String EDITABLE = "Editable";
	
	private static final String NON_EDITABLE = "NonEditable";
	
	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		String actual = "";
		ValidationRequestWrapper requestWrapper = new ValidationRequestWrapper();
		WebElement element = getWebElement( attribute.getFieldDetails());
		validationModel.setComparisonType( ValidationComparisonType.equals);
		if( element != null) {
			actual = !element.isEnabled() ? NON_EDITABLE : EDITABLE;
		} else {
			actual = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		updateParameterValue( validationModel.getVariableName(), actual);
		requestWrapper.addActual(actual);
		return requestWrapper;
	}

	@Override
	public boolean isAttributeBasedValidation() {
		return true;
	}

	@Override
	public boolean isImplicitValidation() {
		return false;
	}

	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}
	
}
