package com.kumaran.tac.framework.selenium.validation;

import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.enums.ValidationComparisonType;
import com.kumaran.tac.common.model.ValidationModel;
import com.kumaran.tac.framework.common.util.FrameworkConstants;

@Component
public class ToolTipMessageValidation extends BaseValidation {

	@Override
	public boolean isAttributeBasedValidation() {
		return true;
	}

	@Override
	public boolean isImplicitValidation() {
		return false;
	}

	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}

	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		ValidationRequestWrapper wrapper = new ValidationRequestWrapper();
		WebElement element = getWebElement( attribute.getFieldDetails());
		String expectedText = validationModel.getExpectedValue();
		validationModel.setComparisonType( ValidationComparisonType.equals);	
		String actual = null;
		if(element != null) {			
			String actualTitle = element.getAttribute("title");
			String actualDataTitle=element.getAttribute("data-original-title");
			if(actualTitle.equals("") && !actualTitle.equals(expectedText)) {
				actual = actualDataTitle;
			} else {
				actual = actualTitle;
			}
		} else if( attribute.getIgnore_ind() == 1) {
			actual = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		updateParameterValue( validationModel.getVariableName(), actual);
		wrapper.addActual(actual);
		return wrapper;
	}

}
