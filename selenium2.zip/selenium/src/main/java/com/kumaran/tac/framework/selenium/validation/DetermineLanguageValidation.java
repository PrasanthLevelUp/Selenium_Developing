package com.kumaran.tac.framework.selenium.validation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.enums.ValidationComparisonType;
import com.kumaran.tac.common.model.ValidationModel;

@Component
public class DetermineLanguageValidation extends BaseValidation {

	@Override
	public boolean isAttributeBasedValidation() {
		return false;
	}

	@Override
	public boolean isImplicitValidation() {
		return false;
	}

	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}

	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		ValidationRequestWrapper wrapper = new ValidationRequestWrapper();
		String expectedValue = validationModel.getExpectedValue();
		JSONParser parser = new JSONParser();
		Map<String, String> actualValMap = new HashMap<>();
		try {
			JSONArray customArray = (JSONArray) parser.parse(expectedValue);
			JSONObject obj = null;
			List<Integer> attrId = new ArrayList<>();
			int attributeId = 0;
			for (int i = 0; i < customArray.size(); i++) {
				obj = (JSONObject) customArray.get(i);
				attributeId = Integer.parseInt(obj.get("attributeId").toString());
				if (!attrId.contains(attributeId)) {
					loop: for (Attribute attr : seleniumExecutor.getAttributes()) {
						if (attr.getId() == attributeId) {
							WebElement element = pageObjectHandler.findObject(attr.getFieldDetails());
							String val = null;
							if (element != null) {
								switch (attr.getType().toUpperCase()) {
								case "BUTTON":
								case "LINK":
								case "label":

									val = element.getText();
									if (val != null) {
										actualValMap.put(attr.getName(), val);
									}
									break loop;
								case "TEXTBOX":
								case "RADIO":
								case "CHECKBOX":
								case "IMAGE":
									val = element.getAttribute("value");
									if (val != null) {
										actualValMap.put(attr.getName(), val);
									}
									break loop;
								case "DROPDOWN":
									Select select = new Select(element);
									WebElement option = select.getFirstSelectedOption();
									val = option.getText();
									if (val != null) {
										actualValMap.put(attr.getName(), val);
									}
									break loop;
								default:
									val = element.getText();
									if (val != null && !val.isEmpty()) {
										actualValMap.put(attr.getName(), val);
									}
									break loop;
								}
							}
						}
					}
					attrId.add(attributeId);
				}
			}
			validationModel.setComparisonType( ValidationComparisonType.in);
			wrapper.addActual( new ObjectMapper().writeValueAsString( actualValMap));
		} catch (Exception e) {
			logger.error("Error", e);
		}
		return wrapper;
	}

}
