package com.kumaran.tac.framework.selenium.validation;

import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.enums.ValidationComparisonType;
import com.kumaran.tac.common.model.ValidationModel;
import com.kumaran.tac.framework.common.util.FrameworkConstants;

@Component
public class VisiblityValidation extends BaseValidation {
	
	private static final String VISIBLE = "Visible";
	
	private static final String NOT_VISIBLE = "Not-Visible";

	@Override
	public boolean isAttributeBasedValidation() {
		return true;
	}

	@Override
	public boolean isImplicitValidation() {
		return false;
	}

	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}

	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		ValidationRequestWrapper requestWrapper = new ValidationRequestWrapper();
		String actual = "";
		WebElement element = getWebElement( attribute.getFieldDetails());
		validationModel.setComparisonType( ValidationComparisonType.equals);
		if( element != null) {
			actual = element.isDisplayed() ? VISIBLE: NOT_VISIBLE;
		} else {
			actual = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		updateParameterValue( validationModel.getVariableName(), actual);
		requestWrapper.addActual(actual);
		return requestWrapper;
	}

}
