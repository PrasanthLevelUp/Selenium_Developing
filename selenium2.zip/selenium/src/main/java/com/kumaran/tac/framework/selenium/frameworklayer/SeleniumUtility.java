package com.kumaran.tac.framework.selenium.frameworklayer;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ExpressionResult;
import com.kumaran.tac.common.dto.FieldDetail;
import com.kumaran.tac.common.enums.BasicFieldType;
import com.kumaran.tac.common.exception.TACException;
import com.kumaran.tac.common.util.AutowireHelperUtil;
import com.kumaran.tac.framework.common.client.AgentClient;
import com.kumaran.tac.framework.common.util.FrameworkConstants;
import com.kumaran.tac.framework.selenium.controller.SeleniumExecutor;
import com.kumaran.tac.framework.selenium.controller.Verification;

@Component
public class SeleniumUtility  {
	private final Logger logger = LoggerFactory.getLogger(SeleniumUtility.class);

	@Autowired
	AgentClient agentClient;
	
	@Autowired
	Verification verification;
	
	@Autowired
	SeleniumExecutor seleniumExecutor;

	private String applicationUrl;
	private String applicationType = "";
	private String applicationBrowserExePath = "";
	private String tableLookupRowData = "";
	private List<String> columnNames = new ArrayList<>();
	private int attributeId;
	
	public String getApplicationURL() {
		return applicationUrl;
	}
	
	public void setApplicationURL( String url) {
		applicationUrl = url;
	}
	
	public String getApplicationType() {
		return applicationType;
	}
	
	public void setApplicationType( String type) {
		applicationType = type;
	}
	
	public String getApplicationBrowserExePath() {
		return applicationBrowserExePath;
	}
	
	public void setApplicationBrowserExePath( String path) {
		applicationBrowserExePath = path;
	}
	
	public String getTableLookupRowData() {
		return tableLookupRowData;
	}
	
	public void setTableLookupRowData( String rowData) {
		tableLookupRowData = rowData;
	}
	
	public List< String> getColumnNames() {
		return columnNames;
	}
	
	public void setColumnNames( List< String> columns) {
		columnNames = columns;
	}
	
	public int getAttributeId() {
		return attributeId;
	}
	
	public void setAttributeId( int id) {
		attributeId = id;
	}
	
	/*public void variableDictionary(JSONObject testDataJson) {
		JSONParser parser = new JSONParser();
		if (testDataJson.get("variables") != null) {
			String varibaleData = testDataJson.get("variables").toString();
			JSONArray variables = null;
			try {
				variables = (JSONArray) parser.parse(varibaleData);

				Iterator<JSONObject> iterator = variables.iterator();

				while (iterator.hasNext()) {
					JSONObject variable = iterator.next();

					for (Object e : variable.entrySet()) {
						Map.Entry entry = (Map.Entry) e;
						if(entry.getValue()!= null){
							
//							seleniumController.Variablesvalue.put(entry.getKey().toString(), entry.getValue().toString());
						}else{
//							seleniumController.Variablesvalue.put(entry.getKey().toString(), null);
						}

					}

				}

			} catch (ParseException e) {
				logger.error( "Error", e);
			}
		}
	}*/

//	public String convertTestDatafromVariable(String transactionData) {
//
//		if (transactionData.startsWith("${") && transactionData.endsWith("}")) {
//			transactionData=transactionData.substring(2, transactionData.length()-1);
//			transactionData = seleniumController.Variablesvalue.get(transactionData);
//		}
//		return transactionData;
//	}
	
	public void transactionDataHandle(Attribute attributes, Map<String, Object> arrtibuteJson) throws Exception {
		attributeId = attributes.getId();
		logger.info("Attribute id : {}" , attributeId);// and
		String transactionData = arrtibuteJson.get(String.valueOf(attributeId)) == null ? ""
				: arrtibuteJson.get(String.valueOf(attributeId)).toString();
		if (transactionData.contains("$")) {
			ExpressionResult expRes = agentClient.getExpressionValue(transactionData);
			transactionData  = expRes.getOutput();
			if ( expRes.hasError()) {
				seleniumExecutor.getFailureDetail().updateFailureDetails(seleniumExecutor.getCurrentAttribute().getId(), 
						seleniumExecutor.getCurrentAttribute().getName(), 
						expRes.getErrorMessage(), "Expression", seleniumExecutor.getTransactionStepId());
				throw new TACException( FrameworkConstants.EXCEPTION_TEST_ERROR);
			}
		}
		if(attributes.getPostDataDefectInd() == 1) {
			if(seleniumExecutor.getStepData().isEmpty()) {
				seleniumExecutor.setStepData(seleniumExecutor.getStepData() + (attributes.getName()+" = "+ transactionData));
			} else {				
				seleniumExecutor.setStepData(seleniumExecutor.getStepData() + (", "+attributes.getName()+" = "+ transactionData));
			}
		}
		List<FieldDetail> fieldDetails = attributes.getFieldDetails();
		BasicFieldType action = attributes.getTypeEnum();
//		if(!attributes.isAutLangInd()) {	
//			String idValue = seleniumController.getFieldIdentificationAtrrVal(attributes.getId());
//			fieldDetails = convertIndentifierValuefromTestData(fieldDetails, idValue);
//		}
		String windowOrFrame = attributes.getWindowOrFrame();
		Integer wait=0;
		if(attributes.getFixedwait() != null){
			wait = attributes.getFixedwait();			
		}
		seleniumExecutor.setMultiElement( 0);
		seleniumExecutor.setFrameAttributeId( attributes.getFrameAttrId());

		if ((verification.getDataVerification().equals( FrameworkConstants.DATA_VERICATION))) {
			if (!transactionData.equalsIgnoreCase("") && !transactionData.equalsIgnoreCase("null")) {
				seleniumExecutor.setTransactionColumnName( attributes.getName());
				if (wait > 0 ) {
					Thread.sleep( (long) wait * 1000);
				}
				Verification verification = AutowireHelperUtil.getBeanObj( Verification.class);
				verification.dataVerificationfeed(transactionData, fieldDetails, action, windowOrFrame, attributes.getClickableInd());
			}
		} else {
			if (!transactionData.equalsIgnoreCase("") && !transactionData.equalsIgnoreCase("null")) {
				seleniumExecutor.setTransactionColumnName( attributes.getName());
				if (wait > 0 ) {
					Thread.sleep( (long) wait * 1000);
				}
				PageObjectHandler pageObjectHandler = AutowireHelperUtil.getBeanObj( PageObjectHandler.class);
				try {						
					pageObjectHandler.dataFeed(transactionData, attributes, windowOrFrame);
				} catch (StaleElementReferenceException e) {
					pageObjectHandler.dataFeed(transactionData, attributes, windowOrFrame);
				}
				// Need to add a Dataverification
			}
		}
	}

	public void mrbTransactionDataHandle(Attribute attributes, Map<String, Object> arrtibuteJson,
			List<FieldDetail> fieldDetails) throws Exception {
		String subMrebssnew = attributes.getType();
		int frameAttribuetId = attributes.getId();
//		String action = arrtibutes.getType();
		BasicFieldType attributeType = attributes.getTypeEnum();
		String windowOrFrame = attributes.getWindowOrFrame();
		seleniumExecutor.setMultiElement( 0);
		int actionField = attributes.getActionField()== null ? 0:attributes.getActionField();
		seleniumExecutor.setFrameAttributeId(  attributes.getParentAttrId());
		String actionColumn = attributes.getColumnName();
		String Name = attributes.getName();

		if (seleniumExecutor.getFrameMap().containsKey(seleniumExecutor.getMrbpId())) {
			seleniumExecutor.setFrameAttributeId( seleniumExecutor.getMrbpId());
			windowOrFrame = "frame";
		}

		if (seleniumExecutor.getFrameMap().containsKey(seleniumExecutor.getFrameAttributeId())) {
			windowOrFrame = "frame";
		}
		Integer wait=0;
		if(attributes.getFixedwait() != null){
			wait = attributes.getFixedwait();			
		}
		String transactionData = arrtibuteJson.get(String.valueOf(frameAttribuetId)) == null ? ""
				: arrtibuteJson.get(String.valueOf(frameAttribuetId)).toString();
		List<FieldDetail> fieldDetailsList = attributes.getFieldDetails();
//		if(!attributes.isAutLangInd()) {	
//			String idValue = seleniumController.getFieldIdentificationAtrrVal(attributes.getId());
//			fieldDetailsList = convertIndentifierValuefromTestData(fieldDetailsList, idValue);
//		}
		attributes.setFieldDetails(fieldDetailsList);
		if (subMrebssnew.equalsIgnoreCase("COLUMNNAME")) {
			tableLookupRowData += transactionData;
			columnNames.add(Name);
		}
		if (subMrebssnew.equalsIgnoreCase("Frame")) {
			seleniumExecutor.getFrameMap().put(Integer.valueOf(frameAttribuetId), attributes.getFieldDetails());
		}
		if (!subMrebssnew.equalsIgnoreCase("grid") && !transactionData.equalsIgnoreCase("null")) {
			if (actionField == 0 && !subMrebssnew.equalsIgnoreCase("ColumnName")
					&& !transactionData.equalsIgnoreCase("")) {
				seleniumExecutor.setTransactionColumnName( attributes.getColumnName());
				if (wait > 0) {
					Thread.sleep( (long) wait * 1000);
				}
				PageObjectHandler pageObjectHandler = AutowireHelperUtil.getBeanObj( PageObjectHandler.class);
				try {						
					pageObjectHandler.dataFeed(transactionData, attributes, windowOrFrame);
				} catch (StaleElementReferenceException e) {
					pageObjectHandler.dataFeed(transactionData, attributes, windowOrFrame);
				}

			} else if (actionField  > 0) {
				seleniumExecutor.setTransactionColumnName( attributes.getName());
				if (seleniumExecutor.getMrbGridType() == null) {
					seleniumExecutor.setTransactionColumnName( attributes.getName());
					if (wait > 0 ) {
						Thread.sleep( (long) wait * 1000);
					}
					PageObjectHandler pageObjectHandler = AutowireHelperUtil.getBeanObj( PageObjectHandler.class);
					pageObjectHandler.tableAction(transactionData, columnNames, tableLookupRowData,
							fieldDetails, attributeType, actionField, windowOrFrame, fieldDetailsList, attributes);
				} else {
					if(  seleniumExecutor.getMrbGridType().toUpperCase().equals( "STANDARD")) {
						if (wait > 0 ) {
							Thread.sleep( (long) wait * 1000);
						}
						PageObjectHandler pageObjectHandler = AutowireHelperUtil.getBeanObj( PageObjectHandler.class);
						pageObjectHandler.tableAction(transactionData, columnNames, tableLookupRowData,
							fieldDetails, attributeType, actionField, windowOrFrame, fieldDetailsList, attributes);
					} else {
						if (wait > 0 ) {
							Thread.sleep( (long) wait * 1000);
						}
						try {
							windowOrFrame=windowOrFrame==null? "":windowOrFrame;
							Object[] obj = { transactionData, columnNames, tableLookupRowData, fieldDetails,
									attributeType, actionField, windowOrFrame, fieldDetailsList };// for
																							// method1()
							Class<?> params[] = new Class[obj.length];
							for (int i = 0; i < obj.length; i++) {
								if (obj[i] instanceof Integer) {
									params[i] = Integer.TYPE;
								} else if (obj[i] instanceof String) {
									params[i] = String.class;
								} else if (obj[i] instanceof WebElement) {
									params[i] = WebElement.class;
								} else if (obj[i] instanceof ArrayList) {
									params[i] = ArrayList.class;
								}
							}
							Class<?> cv = Class.forName( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES);
							if (cv != null) {
								Object objcva = cv.newInstance();
								Method cvmang = cv.getMethod("Custom_tableAction", params);
								if (objcva != null) {
									cvmang.invoke(objcva, (Object[])obj);
								}
							}
						} catch (ClassNotFoundException e) {
							logger.error("Custom Attribute for table not exists : {}", e.getMessage());
						}catch (NoClassDefFoundError e){
							logger.error("Cls def err {}", e.getMessage());
						}
					}
				}
			}
		}
		logger.info( "{} Key of mrb filed {} ",frameAttribuetId, arrtibuteJson.get(String.valueOf(frameAttribuetId)));
	}

	public WebElement attributeWait(WebElement element, Attribute attributes) throws InterruptedException {		
		if(attributes.getAttributeWait()!=null){									
			float timeCount = 0;
			switch(attributes.getAttributeWait()){
			case "visible":
				do {											
					if(element != null && element.isDisplayed()){
						break;
					}else{
						Thread.sleep(100);
						timeCount += 0.1;
						element = findWebElement(attributes.getFieldDetails());
					}
				} while(timeCount< seleniumExecutor.getAttributeMaxWait());
				break;
			case "editable":
				do {											
					if(element != null && element.isEnabled()){												
						break;
					}else{
						Thread.sleep(100);
						timeCount+=0.1;
						element = findWebElement(attributes.getFieldDetails());
					}
				} while(timeCount< seleniumExecutor.getAttributeMaxWait());
				break;
			default:
				break;
			}
		}
		return element;
	}
	
	public WebElement findWebElement(List<FieldDetail> fieldDetails) {
		try {
			PageObjectHandler pageObjectHandler = AutowireHelperUtil.getBeanObj( PageObjectHandler.class);
			return pageObjectHandler.findObject(fieldDetails);
		} catch(Exception e) {
			return null;
		}
	}
}
