package com.kumaran.tac.framework.selenium.validation;

import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.enums.ValidationComparisonType;
import com.kumaran.tac.common.model.ValidationModel;
import com.kumaran.tac.framework.common.util.FrameworkConstants;

@Component
public class TextValidation extends BaseValidation {

	@Override
	public boolean isAttributeBasedValidation() {
		return true;
	}

	@Override
	public boolean isImplicitValidation() {
		return false;
	}

	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}

	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		ValidationRequestWrapper wrapper = new ValidationRequestWrapper();
		int boundaryStart = Integer.parseInt( validationModel.getBoundaryStart());
		int boundaryEnd = Integer.parseInt( validationModel.getBoundaryEnd());
		String actual = null;
		WebElement element = getWebElement( attribute.getFieldDetails());
		if(element != null){
			String actualText;
			actualText= element.getText().trim();
			if(actualText.equals("")) {
				actualText = element.getAttribute("value").trim();				 	
			}
			try {
				actual = actualText.substring(boundaryStart-1, boundaryEnd);
			} catch(Exception e){
				seleniumExecutor.getFailureDetail().setMessage("Validation Type:Text-"+e.getMessage());
				seleniumExecutor.getFailureDetail().setMessageCode("Validation");
			} 
		} else if( attribute.getIgnore_ind() == 1) {
			actual = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		validationModel.setComparisonType( ValidationComparisonType.equals);
		updateParameterValue( validationModel.getVariableName(), actual);
		wrapper.addActual( actual);
		return wrapper;
	}

}
