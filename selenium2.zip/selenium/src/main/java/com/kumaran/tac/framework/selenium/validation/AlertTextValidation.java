package com.kumaran.tac.framework.selenium.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.enums.ValidationComparisonType;
import com.kumaran.tac.common.model.ValidationModel;
import com.kumaran.tac.framework.selenium.frameworklayer.BrowserControls;

@Component
public class AlertTextValidation extends BaseValidation {
	
	@Autowired
	BrowserControls browserControls;
	
	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		ValidationRequestWrapper ret = new ValidationRequestWrapper();
		String actual = browserControls.getDriver().switchTo().alert().getText(); 
		browserControls.getDriver().switchTo().alert().accept();
		ret.addActual( actual);
		validationModel.setComparisonType( ValidationComparisonType.equals);
		updateParameterValue( validationModel.getVariableName(), actual);
		return ret;
	}

	@Override
	public boolean isAttributeBasedValidation() {
		return false;
	}

	@Override
	public boolean isImplicitValidation() {
		return false;
	}

	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}
	
	
}
