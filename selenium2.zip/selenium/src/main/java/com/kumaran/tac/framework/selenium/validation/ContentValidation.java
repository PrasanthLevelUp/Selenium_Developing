package com.kumaran.tac.framework.selenium.validation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.model.ValidationModel;
import com.kumaran.tac.framework.common.util.FrameworkConstants;

@Component
public class ContentValidation extends BaseValidation {
	
	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		ValidationRequestWrapper requestWrapper = new ValidationRequestWrapper();
		WebElement webElement = getWebElement( attribute.getFieldDetails());
		Object actual = contentValidation(webElement, validationModel, attribute);
		requestWrapper.addActual( actual);
		requestWrapper.getValidationRequest().setTacAUTLanguage( seleniumExecutor.getLanguageTACAUT());
		return requestWrapper;
	}
	
	@Override
	public boolean isAttributeBasedValidation() {
		return true;
	}
	
	@Override
	public boolean isImplicitValidation() {
		return false;
	}
	
	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}
	
	public Object contentValidation( WebElement element, ValidationModel validationModel, Attribute attribute) {
		String actual = null;
		if(element != null) {
			switch ( attribute.getType().toLowerCase()) {
				case "textbox":
					actual = getValueForContentValidation(element, validationModel, false);
					break;
				case "dropdown":
					Select select = new Select(element);
					WebElement option = select.getFirstSelectedOption();
					actual = getValueForContentValidation(option, validationModel, true);
					break;
				default:
					actual = getValueForContentValidation(element, validationModel, true);
					break;
			}
		} else if( attribute.getIgnore_ind() == 1) {
			actual = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		updateParameterValue( validationModel.getVariableName(), actual);
		return actual;
	}
	
	private String getValueForContentValidation(WebElement element, ValidationModel validationModel, boolean getTextInd) {
		String source = validationModel.getSource() != null ? validationModel.getSource() : "value";
		String value = null;
		switch (source) {
		case "style" :
			return element.getCssValue( validationModel.getStyle());
		case "class" :
			return element.getAttribute(source);
		case "value":
		case "length" :
			return getTextInd ? element.getText() : element.getAttribute("value");		
		case "attribute" :
			return element.getAttribute( validationModel.getAttribute().toString());
		default :
			logger.warn("No value found for source : {}", source);
			break;
		}
		return value;
	}
}
