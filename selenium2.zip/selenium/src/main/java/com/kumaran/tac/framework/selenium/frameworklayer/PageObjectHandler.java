package com.kumaran.tac.framework.selenium.frameworklayer;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.FieldDetail;
import com.kumaran.tac.common.enums.BasicFieldType;
import com.kumaran.tac.common.exception.TACException;
import com.kumaran.tac.framework.common.client.AgentClient;
import com.kumaran.tac.framework.common.util.FrameworkConstants;
import com.kumaran.tac.framework.selenium.controller.SeleniumExecutor;

@Component
public class PageObjectHandler {
	public static final Logger mainLogger = LoggerFactory.getLogger(PageObjectHandler.class);

	@Autowired
	AgentClient agentClient;

	@Autowired
	PageObjectHandler pageObjectHandler;
	
	@Autowired
	BrowserControls browserControls;
	
	@Autowired
	SeleniumUtility seleniumUtility;
	
	@Autowired
	SeleniumExecutor seleniumExecutor;
	
	private WebElement transactionElement = null;
	private String failureReason = null;
	private boolean translate = false;
	
	public WebElement getTransactionElement() {
		return transactionElement;
	}
	
	public void setTransactionElement( WebElement element) {
		transactionElement = element;
	}
	
	public String getFailureReason() {
		return failureReason;
	}
	
	public void setFailureReason( String reason) {
		failureReason = reason;
	}
	
	// Find pageObject for WebApplication
	public WebElement findObject(List<FieldDetail> fieldDetail) {
		WebElement element = null;
		List<WebElement> elements;
		fielDetailsloop: for (int i = 0; i < fieldDetail.size(); i++) {
			FieldDetail fieldIdentifier = fieldDetail.get(i);
			browserControls.waitPageloadComplete();
			By valueBy = findobjectBy(fieldIdentifier);
			browserControls.explicitWaitForObjectFoundBy(valueBy);
			if (valueBy == null) {
				continue;
			}
			elements = browserControls.getDriver().findElements(valueBy);
			if (seleniumExecutor.getMultiElement() > 0) {
				try {
					if (element != null && !elements.isEmpty()) {
						element = elements.get( seleniumExecutor.getMultiElement() - 1);
						break;
					}
				} catch (Exception e) {
					// ignoring exception
				}
			} else {
				try {
					element = browserControls.getDriver().findElement(valueBy);
				} catch (ElementNotVisibleException e) {
					mainLogger.error( "Error occurred : ",e);
				} catch (NoSuchElementException noElementException) {
					mainLogger.error( "Element not found");
				} catch (NoSuchWindowException noWindowEx) {
					throw new NoSuchWindowException("window has closed unfortunately or due to manual intraction");
				}
			}
			if(element != null){
				translate = fieldIdentifier.getTranslateInd() == 1; 
			}
		}
		
		StringBuilder objectdata = new StringBuilder();
		for (int i = 0; i < fieldDetail.size(); i++) {
			String fieldType = fieldDetail.get(i).getType();
			String fieldValue = fieldDetail.get(i).getValue();
			objectdata.append( fieldType + ":" + fieldValue + ",");
		}

		if (element == null) {
			if (seleniumExecutor.getMultiElement() > 0) {
				throw new NoSuchElementException("Multielement position of " + seleniumExecutor.getMultiElement()
						+ " Field  \"" + seleniumExecutor.getTransactionColumnName() + "\" element not found in "
						+ seleniumExecutor.getTransactionName() + " transaction of step id" + seleniumExecutor.getTransactionStepId());
			} else {
				failureReason = "Field name \"" + objectdata + " " + seleniumExecutor.getTransactionColumnName()
						+ "\" element not found in " + seleniumExecutor.getTransactionName() + " transaction of step id "
						+ seleniumExecutor.getTransactionStepId();
				throw new NoSuchElementException(failureReason);
			}
		} else {
			transactionElement = element;
		}
		return element;
	}

	public List<WebElement> findAllObjects( List<FieldDetail> fieldDetail) {
		List<WebElement> elements = new ArrayList<>();
			for(FieldDetail fieldIdentifier : fieldDetail) {
				browserControls.waitPageloadComplete();
				By valueBy = findobjectBy(fieldIdentifier);
				browserControls.explicitWaitForObjectFoundBy(valueBy);
				if (valueBy == null) {
					continue;
				}
				try {
					elements = browserControls.getDriver().findElements(valueBy);
				} catch (Exception e) {
					mainLogger.error("Error occured in findAllObjects method ",e);
				} 
		}
		return elements;
	}
	
	public By findobjectBy(FieldDetail fieldIdentifier) {
		String value = fieldIdentifier.getValue();
		By valueBy = null;
		switch (fieldIdentifier.getType().toUpperCase()) {
			case "ID":
				valueBy = By.id(value);
				break;
			case "CSSSELECTOR":
				valueBy = By.cssSelector(value);
				break;
			case "XPATH":
				valueBy = By.xpath(value);
				break;
			case "NAME":
				valueBy = By.name(value);
				break;
			case "CLASS":
				valueBy = By.className(value);
				break;
			case "LINKTEXT":
				valueBy = By.linkText(value);
				break;
			case "PARTIALLINKTEXT":
				valueBy = By.partialLinkText(value);
				break;
			case "TAGNAME":
				valueBy = By.tagName(value);
				break;
			default : 
				mainLogger.error( "Unable to perform action for Field Identifier : {}", fieldIdentifier);
		}
		return valueBy;
	}

	public void fieldAction(BasicFieldType action, String testData, Attribute attributes) throws InterruptedException {
		boolean clickableInd = attributes.getClickableInd();
		browserControls.waitPageloadComplete();
		browserControls.explicitWaitForObjectFound(transactionElement);
		browserControls.scrollToElement(transactionElement);
		browserControls.highlightElements(transactionElement, "feed");
		if (action.equals(BasicFieldType.LABEL) || action.equals(BasicFieldType.IMAGE) || transactionElement.isEnabled()) {
		switch (action) {
			case TEXTBOX:
	                transactionElement.clear();
	                if (!testData.equalsIgnoreCase( FrameworkConstants.TAC_CLEAR_DATA)) {
	                    transactionElement.sendKeys(testData);
	            }
				break;
			case LINK:
			case BUTTON:	
			case RADIO:
				handleClickableElements(transactionElement, testData);
				break;
			case CHECKBOX:
				handleCheckbox(transactionElement, testData);
				break;
			case DROPDOWN:
				if (testData.trim().length() > 0) {
					int i;
					for (i = 1; i <= 200; i++) {
						try {
							Select dropdown = new Select(transactionElement);
							if (testData.equalsIgnoreCase( FrameworkConstants.TAC_CLEAR_DATA)) {
								List<WebElement> dropdownElements = dropdown.getOptions();
								if (dropdownElements != null && !dropdownElements.isEmpty()) {
									WebElement firstOption = dropdownElements.get(0);
									firstOption.click();
								}
							} else {
								dropdown.selectByVisibleText(testData);
							}
							break;
						} catch (Exception e) {
							mainLogger.warn("Drop down is not loaded. Sleeping for 100ms.");
							Thread.sleep(100);
						}
					}
					if (i == 201) {
						throw new ElementNotVisibleException(seleniumExecutor.getTransactionColumnName() + " Dropdown value not found "
								+ testData + " with step Id " + seleniumExecutor.getTransactionStepId());
					}
				}
				break;
			case LABEL:
			case IMAGE:
				if(clickableInd) {
					handleClickableElements(transactionElement, testData);
				}
				break;
			default:
				try {
					Object[] obj = {action,testData,transactionElement};// for method1()
			        Class<?> params[] = new Class[obj.length];
			        for (int i = 0; i < obj.length; i++) {
			            if (obj[i] instanceof Integer) {
			                params[i] = Integer.TYPE;
			            } else if (obj[i] instanceof String) {
			                params[i] = String.class;
			            }else if (obj[i] instanceof WebElement) {
			                params[i] = WebElement.class;
			            }
			        }
					Class<?> fa = Class.forName( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES);
					if( fa!=null) {
						 Object objfa = fa.newInstance();
						 Method fam =  fa.getMethod("Custom_fieldAction",params);
						 if( fam!=null) {
							 mainLogger.info("Custom_fieldAction- Start TOGGLE");
							 fam.invoke(objfa,obj); 
						 }
					}
				} catch (InstantiationException e) {
					mainLogger.error( "Error in fieldAction", e);
				} catch (IllegalAccessException e1) {
					mainLogger.error( "Error in fieldAction", e1);
				} catch (NoSuchMethodException e2) {
					mainLogger.error( "Error in fieldAction", e2);
				} catch (SecurityException e3) {
					mainLogger.error( "Error in fieldAction", e3);
				} catch (ClassNotFoundException e4) {
					mainLogger.error( "Error in fieldAction", e4);
				} catch (IllegalArgumentException e5) {
					mainLogger.error( "Error in fieldAction", e5);
				} catch (InvocationTargetException e6) {
					mainLogger.error( "Error in fieldAction", e6);
				} 
				break;	
		}
		}
		else {
			seleniumExecutor.getFailureDetail().updateFailureDetails(attributes.getId(), attributes.getName(),
					FrameworkConstants.MESSAGE_ELEMENT_NOT_ENABLED, FrameworkConstants.MESSAGE_CODE_NOT_ENABLED,
					seleniumExecutor.getTransactionStepId() );
			throw new TACException( FrameworkConstants.EXCEPTION_TEST_FAIL);
		}
	}
	

	public void hiddenElementfieldAction(String action, String testData) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) browserControls.getDriver();
		String clickScript = "arguments[0].click();";
		switch (action.toUpperCase()) {
			case "TEXTBOX":
				js.executeScript("arguments[0].setAttribute('value','" + testData + "')", transactionElement);
				break;
			case "BUTTON":
				js.executeScript( clickScript, transactionElement);
				break;
			case "LINK":
				js.executeScript( clickScript, transactionElement);
				break;
			case "RADIO":
				js.executeScript( clickScript, transactionElement);
				break;
			case "CHECKBOX":
				js.executeScript( clickScript, transactionElement);
				break;
			default:
				try {
					Class<?> fa = Class.forName( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES);
					if(fa!=null){
						 Object objfa = fa.newInstance();
						 Method fam =  fa.getMethod("Custom_fieldAction");
						 if(fam!=null){
							 fam.invoke(objfa); 
						 }
					 }
				} catch (NoClassDefFoundError e){
					mainLogger.error("Class definition not found : {}", e.getMessage());
				} catch (InstantiationException e) {
					mainLogger.error( "Error in hiddenElementfieldAction", e);
				} catch (IllegalAccessException e1) {
					mainLogger.error( "Error in hiddenElementfieldAction", e1);
				} catch (NoSuchMethodException e2) {
					mainLogger.error( "Error in hiddenElementfieldAction", e2);
				} catch (SecurityException e3) {
					mainLogger.error( "Error in hiddenElementfieldAction", e3);
				} catch (ClassNotFoundException e4) {
					mainLogger.error( "Error in hiddenElementfieldAction", e4);
				} catch (IllegalArgumentException e5) {
					mainLogger.error( "Error in hiddenElementfieldAction", e5);
				} catch (InvocationTargetException e6) {
					mainLogger.error( "Error in hiddenElementfieldAction", e6);
				} catch (Exception e7){
					mainLogger.error( "Error in hiddenElementfieldAction", e7);
				}
				break;	
			
		}

	}

	public void dataFeed(String testdata, Attribute attribute, String type) {
		BasicFieldType action = attribute.getTypeEnum();
		List<FieldDetail> fieldIdentifiers = attribute.getFieldDetails();
		boolean clickableInd = attribute.getClickableInd();
		SwitchContainer switchContainer = new SwitchContainer(type);
		switchContainer.giveControl();
		if (!action.equals(BasicFieldType.ALERT) && !attribute.isAutLangInd()) {
			try {
				WebElement ele = findObject(fieldIdentifiers);
				seleniumUtility.attributeWait(ele, attribute);
				if(translate) {
					testdata = seleniumExecutor.translateTestData(testdata);
				}
				fieldAction(action, testdata, attribute);
			} catch (InterruptedException e) {
				mainLogger.error("InterruptedException has occured while identifying the WebElement ", e);
			} catch (NoSuchElementException | StaleElementReferenceException e) {
				if(attribute.getIgnore_ind() != 1) {
					handleException(attribute, e);
				}
			}
		} else if (attribute.isAutLangInd()) {
			List<Map<String,Object>> autLangOptions = attribute.getAutLangOptions();
			for(Map<String,Object>lang : autLangOptions) {
				if(lang.get("language").toString().equalsIgnoreCase(testdata)) {
					String localTestData = lang.get("actionValue").toString();
					Attribute localAttr = null;
					Map<String,Map<String,Object>> attrVal = (Map<String,Map<String,Object>>)lang.get("attribute");
					Integer id = Integer.parseInt(attrVal.get("value").get("id").toString());
					for(Attribute attr : seleniumExecutor.getAttributes()) {
						if(id.equals(attr.getId())) {
							localAttr = attr;
						}
					}
					try {
						WebElement ele = findObject(localAttr.getFieldDetails());
						seleniumUtility.attributeWait(ele, localAttr);
						fieldAction(localAttr.getTypeEnum(), localTestData, attribute);
					} catch (InterruptedException e) {
						mainLogger.error("InterruptedException has occured while identifying the WebElement ", e);
					} catch (NoSuchElementException | StaleElementReferenceException e) {
						if(attribute.getIgnore_ind() != 1) {
							handleException(attribute, e);
						}
					}
					Map<String, String> variable = new  HashMap<>();
					variable.put("tac_aut_language", testdata);
					agentClient.updateVariableValue(variable);
					seleniumExecutor.setLanguageTACAUT( testdata);
				}
			}
		} else {
			if (testdata.contains("|")) {
				String[] alertSplit = testdata.split("\\|");
				applicationPopup(alertSplit[0], alertSplit[1]);
			} else {
				applicationPopup(testdata, "");
			}
		}
		switchContainer.takeBackControl();
	}
	
	private void handleException( Attribute attribute, Exception e) {
		seleniumExecutor.getFailureDetail().updateFailureDetails(attribute.getId(), attribute.getName(), 
				"error occured while identifying the WebElement", "Not found", seleniumExecutor.getTransactionStepId());
		if( e instanceof StaleElementReferenceException) {
			seleniumExecutor.getFailureDetail().setMessage(seleniumExecutor.getFailureDetail().getMessage()+
					"; StaleElementReferenceException occured");
			throw (StaleElementReferenceException) e;
		}
		if( !seleniumExecutor.isContinueOnFailure()) {
			throw new TACException( FrameworkConstants.EXCEPTION_TEST_FAIL);
		}
	}

	// UnExpected alert to be handle
	public void unExpectedAlert(String action) {
		if (isAlertPresents()) {
			Alert alert = browserControls.getDriver().switchTo().alert();
			if (action.equalsIgnoreCase("OK") || action.equalsIgnoreCase("Yes")) {
				alert.accept();
			} else if (action.equalsIgnoreCase("cancel")) {
				alert.dismiss();
			}
		}
	}

	// Handle the popup in the application
	public void applicationPopup(String action, String popUptext) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			mainLogger.debug( "Sleep interrupted", e);
		}
		if (isAlertPresents()) {
			Alert alert = browserControls.getDriver().switchTo().alert();
			if (!popUptext.equalsIgnoreCase("")) {
				alert.sendKeys(popUptext);
			}
			if (action.equalsIgnoreCase("OK") || action.equalsIgnoreCase("Yes")) {
				mainLogger.info( "Alert is present");
				alert.accept();
			} else if (action.equalsIgnoreCase("cancel")) {
				alert.dismiss();
			}
		} else {
			mainLogger.info( "Alert is not present");
		}
	}

	// alert is Alert Present or not
	public boolean isAlertPresents() {
		try {
			WebDriverWait wait = new WebDriverWait(browserControls.getDriver(), 3);
			wait.until(ExpectedConditions.alertIsPresent());
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// Switch to Frame

	public void frameHandle( List<FieldDetail> fieldDeatils) {
		browserControls.getDriver().switchTo().frame( findObject(fieldDeatils));
	}

	public void tableAction(String testData, List<String> columnName, String tableData,
			List<FieldDetail> gridFieldIdentifiers, BasicFieldType actionType, int action, String type,
			List<FieldDetail> fieldIdentifiers, Attribute attribute) throws Exception {
		boolean frameFlag = false;
		browserControls.waitPageloadComplete();
		SwitchContainer switchContainer = new SwitchContainer( type);
		switchContainer.giveControl();
		List<Integer> postionOfTableColumn = new ArrayList<>();
		WebElement table = findObject(gridFieldIdentifiers);
		browserControls.highlightElements(table, "feed");
		List<WebElement> tr = table.findElements(By.tagName("tr"));
		List<WebElement> th = tr.get(0).findElements(By.tagName("th"));
		if (th.isEmpty()) {
			th = tr.get(0).findElements(By.tagName("td"));
		}
		for (int i = 0; i < th.size(); i++) {
			for (String TableHeader : columnName) {
//				if (th.get(i).getText().equalsIgnoreCase(TableHeader)) {
				if (TableHeader.equalsIgnoreCase(th.get(i).getText().trim())) {
					postionOfTableColumn.add(i);
				}
			}
		}

		if ( postionOfTableColumn.isEmpty() || columnName.size() != postionOfTableColumn.size()) {
			throw new TACException("Column name not found in Table " + columnName.toString());
		}
		WebElement actionElement = null;
		outerloop: for (int i = 1; i < tr.size(); i++) {
			List<WebElement> td = tr.get(i).findElements(By.tagName("td"));
			StringBuilder tableColumnDataBuilder = new StringBuilder();
			for (int j = 0; j < postionOfTableColumn.size(); j++) {
				try{
					tableColumnDataBuilder.append( td.get(postionOfTableColumn.get(j)).getText());
				}catch(Exception e){
					tableColumnDataBuilder = new StringBuilder("");
				}
			}
			if ( tableColumnDataBuilder.toString().equalsIgnoreCase(tableData)) {
				WebElement actionColumn = td.get(action - 1);
				if (fieldIdentifiers.isEmpty()) {
					switch(actionType) {
					case TEXTBOX:
						actionElement = actionColumn.findElement(By.cssSelector(("input[type='text']")));
					break;
					case BUTTON:
						List<WebElement> li=actionColumn.findElements(By.cssSelector(("input[type='button']")));
						List<WebElement> li1=actionColumn.findElements(By.tagName(("button")));
						if (( li.size()>1 && !testData.equalsIgnoreCase( FrameworkConstants.ACTION_CLICK)) || li.size()==1) {
							actionElement = actionColumn.findElement(By.cssSelector(("input[type='button'][value*='"+ testData +"']")));
						}
						if (li1.size()>1  && !testData.equalsIgnoreCase( FrameworkConstants.ACTION_CLICK)) {
							actionElement = actionColumn.findElement(By.cssSelector(("button[text()*='"+ testData +"']")));
						} else if (li1.size()==1 ){
							actionElement = actionColumn.findElement(By.tagName("button"));
						}
					break;
					case CHECKBOX:
						actionElement = actionColumn.findElement(By.cssSelector(("input[type='checkbox']")));
					break;
					case RADIO:
						actionElement = actionColumn.findElement(By.cssSelector(("input[type='radio']")));
					break;
					case DROPDOWN:
						actionElement = actionColumn.findElement(By.tagName(("select")));
					break;
					case LINK:
						actionElement = actionColumn.findElement(By.tagName("a"));
					break;
					default:
						break;
					}
				} else {
					for (int field = 0; field < fieldIdentifiers.size(); field++) {
						FieldDetail fieldIdentifier = fieldIdentifiers.get(field);
						By valueBy = findobjectBy(fieldIdentifier);
						switch (actionType) {
						case TEXTBOX:
						case BUTTON:
						case CHECKBOX:
						case RADIO:
						case DROPDOWN:
						case LINK:
							actionElement = actionColumn.findElement(valueBy);
							break;
						default:
							break;

						}
					}
				}
				transactionElement = actionElement;
				break outerloop;
			}

		}
		if (actionElement == null) {
			throw new TACException("Table Column " + seleniumExecutor.getTransactionColumnName() + " " + actionType + "not found in "
					+ seleniumExecutor.getTransactionName() + "with step id" + seleniumExecutor.getTransactionStepId());
		}
		fieldAction(actionType, testData, attribute);
		switchContainer.takeBackControl();
	}

	public void handleClickableElements(WebElement element, String testData) {
		if(testData.equalsIgnoreCase( FrameworkConstants.ACTION_CLICK)) {
			element.click();
		} else if(testData.equalsIgnoreCase( FrameworkConstants.ACTION_DOUBLE_CLICK)) {
			browserControls.getAction().doubleClick(element).perform();
		}
	}

	public void handleCheckbox(WebElement element, String testData) {
		switch (testData.toLowerCase()) {
			case FrameworkConstants.ACTION_CHECK:
				if (!element.isSelected()) {
					element.click();
				}
				break;
			case FrameworkConstants.TAC_CLEAR_DATA:
			case FrameworkConstants.ACTION_UNCHECK:
				if (element.isSelected()) {
					element.click();
				}
				break;
			case FrameworkConstants.ACTION_CLICK:
			case FrameworkConstants.ACTION_TOGGLE:
				element.click();
				break;
			default:break;
		}
	}
	
}
