package com.kumaran.tac.framework.selenium.frameworklayer;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kumaran.tac.common.dto.FieldDetail;
import com.kumaran.tac.common.exception.TACException;
import com.kumaran.tac.common.util.AutowireHelperUtil;
import com.kumaran.tac.framework.selenium.controller.SeleniumExecutor;

public class SwitchContainer {
	
	public static final Logger logger = LoggerFactory.getLogger( SwitchContainer.class);
	
	private String type;
	
	private String parentWindow;
	
	private boolean switchedToFrame;
	
	public SwitchContainer( String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}

	public String getParentWindow() {
		return parentWindow;
	}

	public void setParentWindow(String parentWindow) {
		this.parentWindow = parentWindow;
	}

	public boolean isSwitchedToFrame() {
		return switchedToFrame;
	}

	public void setSwitchedToFrame(boolean switchedToFrame) {
		this.switchedToFrame = switchedToFrame;
	}
	
	public void giveControl() {
		try {
			if ( getType() != null) {
				BrowserControls browserControls = AutowireHelperUtil.getBeanObj( BrowserControls.class);
				SeleniumExecutor seleniumExecutor = AutowireHelperUtil.getBeanObj( SeleniumExecutor.class);
				PageObjectHandler pageObjectHandler = AutowireHelperUtil.getBeanObj( PageObjectHandler.class);
				if ( getType().startsWith("window")) {
					String window = browserControls.windowsHandeling();
					setParentWindow( window);
					logger.info( "Control switched to window : {}", window);
				} else if ( getType().contains("frame")) {
					setSwitchedToFrame( true);
					List<FieldDetail> fieldDetail = seleniumExecutor.getFrameMap().get( seleniumExecutor.getFrameAttributeId());
					pageObjectHandler.frameHandle(fieldDetail);
					logger.info( "Control switched to frame.");
				} else {
					logger.debug( "Control will not switch as type is {}", type);
				}
			} else {
				logger.debug( "Control will not switch as type is {}", type);
			}
		} catch ( Exception e) {
			throw new TACException( "Error while switching to container", e);
		}
	}
	
	public void takeBackControl() {
		try {
			BrowserControls browserControls = AutowireHelperUtil.getBeanObj( BrowserControls.class);
			if( getType() == null) {
				logger.debug( "Control will not switch as type is {}", type);
				return;
			}
			if ( getParentWindow() != null) {
				browserControls.getDriver().switchTo().window( getParentWindow());
			}
			if ( isSwitchedToFrame()) {
				browserControls.getDriver().switchTo().defaultContent();
			}
		} catch( Exception e) {
			throw new TACException( "Error while switching to container", e);		
		}
	}

}
