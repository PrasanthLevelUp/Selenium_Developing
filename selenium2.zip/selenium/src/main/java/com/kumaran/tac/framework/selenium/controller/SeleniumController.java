package com.kumaran.tac.framework.selenium.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.model.ValidationModel;
import com.kumaran.tac.framework.common.client.AgentClient;
import com.kumaran.tac.framework.common.executor.Executor;
import com.kumaran.tac.framework.common.validation.IValidation;
import com.kumaran.tac.framework.selenium.frameworklayer.BrowserControls;
import com.kumaran.tac.framework.selenium.frameworklayer.PageObjectHandler;
import com.kumaran.tac.framework.selenium.frameworklayer.SeleniumUtility;

@Component
@Configuration
public class SeleniumController {
	private static final Logger logger = LoggerFactory.getLogger(SeleniumController.class);

	@Autowired
	AgentClient agentClient;
	
	@Autowired
	PageObjectHandler pageObjectHandler;
	
	@Autowired
	BrowserControls browserControls;
	
	@Autowired
	SeleniumUtility seleniumUtility;
	
	public static void main(String[] args) throws Exception {
		logger.info("Selenium started");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		SeleniumUtility seleniumUtility = context.getBean( SeleniumUtility.class);
		seleniumUtility.setApplicationType( "web");
		
		AgentClient agentClient = context.getBean( AgentClient.class);
		agentClient.start();
	}
	
}
