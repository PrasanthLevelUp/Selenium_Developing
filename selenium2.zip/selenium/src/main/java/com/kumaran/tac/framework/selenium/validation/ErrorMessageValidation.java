package com.kumaran.tac.framework.selenium.validation;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.FrameworkValidationEntity;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.exception.TACException;
import com.kumaran.tac.common.model.ValidationModel;

@Component
public class ErrorMessageValidation extends BaseValidation {

	@Override
	public boolean isAttributeBasedValidation() {
		return false;
	}

	@Override
	public boolean isImplicitValidation() {
		return true;
	}

	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}

	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		ValidationRequestWrapper wrapper = new ValidationRequestWrapper();
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			wrapper.addActual( objectMapper.writeValueAsString(seleniumExecutor.getErrorMessages()));
		} catch (Exception e) {
			throw new TACException(e);
		}
		return wrapper;
	}
	
	@Override
	public void postValidation(ValidationModel validationModel, Attribute attributes, FrameworkValidationEntity validationResponse) {
		try {
			logger.info( "Performing post validation for ErrorMessage validation with agent response : {}", validationResponse);
			ObjectMapper mapper = new ObjectMapper();
			if( validationResponse.getFailureReason() != null) {
				String residualErrorMsgs = mapper.writeValueAsString( validationResponse.getFailureReason());
				updateErrorMessage( residualErrorMsgs);
			} else {
				seleniumExecutor.setErrorMessages( new ArrayList<>());
			}
		}  catch ( Exception e) {
			throw new TACException(e);
		}
	}
	
	private void updateErrorMessage( String residualErrorMsgs) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			seleniumExecutor.setErrorMessages( mapper.readValue(residualErrorMsgs, new TypeReference<ArrayList<String>>() {}));
		} catch(Exception e) {
			seleniumExecutor.setErrorMessages( new ArrayList<>());
		}
	}

}
