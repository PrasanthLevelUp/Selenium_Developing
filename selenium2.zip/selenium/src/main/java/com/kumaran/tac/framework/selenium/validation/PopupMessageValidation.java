package com.kumaran.tac.framework.selenium.validation;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.UnhandledAlertException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.dto.Attribute;
import com.kumaran.tac.common.dto.ValidationRequestWrapper;
import com.kumaran.tac.common.enums.ValidationComparisonType;
import com.kumaran.tac.common.model.ValidationModel;
import com.kumaran.tac.framework.selenium.frameworklayer.BrowserControls;

@Component
public class PopupMessageValidation extends BaseValidation {
	
	@Autowired
	BrowserControls browserControls;

	@Override
	public boolean isAttributeBasedValidation() {
		return false;
	}

	@Override
	public boolean isImplicitValidation() {
		return false;
	}

	@Override
	public boolean hasMultipleActualValue() {
		return false;
	}

	@Override
	public ValidationRequestWrapper executeInternal(ValidationModel validationModel, Attribute attribute)
			throws Exception {
		ValidationRequestWrapper requestWrapper = new ValidationRequestWrapper();
		Document doc1 = null;
		String actual = null;
		try {
			doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
		} catch (UnhandledAlertException e) {
			doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
		}
		actual = doc1.select("html").text();
		updateParameterValue( validationModel.getVariableName(), actual);
		validationModel.setComparisonType( ValidationComparisonType.contains);
		requestWrapper.addActual(actual);
		return requestWrapper;
	}

}
