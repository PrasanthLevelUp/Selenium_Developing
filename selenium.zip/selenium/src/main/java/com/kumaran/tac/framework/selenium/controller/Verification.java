package com.kumaran.tac.framework.selenium.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.enums.BasicFieldType;
import com.kumaran.tac.framework.common.dto.Attributes;
import com.kumaran.tac.framework.common.dto.FieldDetails;
import com.kumaran.tac.framework.common.dto.TestStepData;
import com.kumaran.tac.framework.common.dto.Transactions;
import com.kumaran.tac.framework.common.util.FrameworkConstants;
import com.kumaran.tac.framework.selenium.frameworklayer.BrowserControls;
import com.kumaran.tac.framework.selenium.frameworklayer.PageObjectHandler;
import com.kumaran.tac.framework.selenium.frameworklayer.SeleniumUtility;

@Component
public class Verification {
	
	@Autowired
	SeleniumController seleniumController;
	
	@Autowired
	PageObjectHandler pageObjectHandler;
	
	@Autowired
	BrowserControls browserControls;
	
	@Autowired
	SeleniumUtility seleniumUtility;
	
	private String dataVerification ="";
	private Map<Integer, String> dvStatus;
	private  Map<String, Object> dvMapPassStatus = new HashMap<>();
	private final Logger logger = LoggerFactory.getLogger(Verification.class);
	
	public String getDataVerification() {
		return dataVerification;
	}
	
	public void setDataVerification( String verification) {
		dataVerification = verification;
	}
	
	public Map< String, Object> getDVMapPassStatus() {
		return dvMapPassStatus;
	}
	
	public void setDVMapPassStatus( Map< String, Object> map) {
		dvMapPassStatus = map;
	}
	
	public void dataVerificationFromMaptoAppliaction(TestStepData testDataJson,int i) throws Exception {
		dataVerification = FrameworkConstants.DATA_VERICATION;	
		seleniumController.setFrameMap( new HashMap<>());
		seleniumController.setTransactionStepId( testDataJson.getStepId());
		logger.info("transactionStepId : {}" , seleniumController.getTransactionStepId());
		seleniumController.setTransactionId( testDataJson.getTransactionId().toString());
		logger.info("transactionId : {}" , seleniumController.getTransactionId());
		seleniumController.setTransactionColumnName( "");	
		List<Map<String, Object>> readMrbFromMap = new ArrayList<>();
		List<Transactions> transactionList = seleniumController.getORObject().getTransactions();
		List<Map<String, Object>> arrtibuteJson = testDataJson.getAttributeTestData();
		int testDataSize = arrtibuteJson.size();
		Transactions transaction = transactionList.get(i);
		int orTransctionId = transaction.getTransactionId();
		logger.info("orTransctionId : {}", orTransctionId);
		if (orTransctionId == Integer.valueOf( seleniumController.getTransactionId())) {
			for (int a = 0; a < testDataSize; a++) {
				Map<String, Object> singleTestDataJsonObject = arrtibuteJson.get(a);
				seleniumController.setTransactionName( transaction.getTransactionName());
				boolean isParent = false;
				ArrayList<Attributes> attributesList = transaction.getAttributes();
				int size = attributesList.size();
				logger.info( "attribute size = {}", size);
				for (int j = 0; j < attributesList.size(); j++) {
					Attributes arrtibutes = attributesList.get(j);
					int attributeId = arrtibutes.getId();
					int parentAttributeId = arrtibutes.getParentAttrId();
					// String mrbgrid = arrtibutes.getType();
					String mrbgrid = arrtibutes.getType();
					if (mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME)) {
						seleniumController.getFrameMap().put(Integer.valueOf(attributeId), arrtibutes.getFieldDetails());
					}
					if (parentAttributeId == 0 && !mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID) && !isParent
							&& !mrbgrid.equalsIgnoreCase(  FrameworkConstants.CONTAINER_ELEMENT_FRAME) 
							&& !mrbgrid.equalsIgnoreCase(  FrameworkConstants.CONTAINER_ELEMENT_WINDOW_DIALOG)) {
						// TestData as array
						seleniumUtility.transactionDataHandle(arrtibutes, singleTestDataJsonObject);
					}
					if (parentAttributeId == 0 && arrtibutes.getType().equalsIgnoreCase(  FrameworkConstants.CONTAINER_ELEMENT_GRID)
							|| arrtibutes.getType().equalsIgnoreCase(  FrameworkConstants.CONTAINER_ELEMENT_WINDOW_DIALOG)
							|| arrtibutes.getType().equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME) && !isParent) {
						attributeId = arrtibutes.getId();
						readMrbFromMap = (ArrayList) singleTestDataJsonObject.get(String.valueOf(attributeId));
						logger.info("MRB content : {}", readMrbFromMap);
						isParent = true;
						List<FieldDetails> mrbFieldDeatils = arrtibutes.getFieldDetails();
						for (int mrbcount = 0; mrbcount < readMrbFromMap.size(); mrbcount++) {
							Map<String, Object> readListOfMrbs = readMrbFromMap.get(mrbcount);
							seleniumUtility.setTableLookupRowData( "");
							seleniumUtility.setColumnNames( new ArrayList<>());
							for (int l = j; l < attributesList.size(); l++) {
								Attributes mrbAttributes = attributesList.get(l);
								seleniumController.setMrbpId( mrbAttributes.getParentAttrId());
								String subMrebssnew = mrbAttributes.getType();
								if ( seleniumController.getMrbpId() == attributeId && mrbgrid.equalsIgnoreCase("window")) {
									seleniumUtility.mrbTransactionDataHandle(mrbAttributes, readListOfMrbs, mrbFieldDeatils);
								}

								if ( seleniumController.getMrbpId() == attributeId && mrbgrid.equalsIgnoreCase("frame")) {
									seleniumUtility.mrbTransactionDataHandle(mrbAttributes, readListOfMrbs, mrbFieldDeatils);
								}

								if ( seleniumController.getMrbpId() == attributeId && mrbgrid.equalsIgnoreCase("grid")
										&& !subMrebssnew.equalsIgnoreCase("grid")) {
									seleniumUtility.mrbTransactionDataHandle(mrbAttributes, readListOfMrbs, mrbFieldDeatils);

								} else if ( seleniumController.getMrbpId() == attributeId && subMrebssnew.equalsIgnoreCase("grid")) {
									int subsubreb = mrbAttributes.getId();
									List<FieldDetails> subMrbFieldDeatils = mrbAttributes.getFieldDetails();
									List<Map<String, Object>> readSubMrb = (List<Map<String, Object>>) readListOfMrbs
											.get(String.valueOf(subsubreb));
									logger.info("Sub mrabs data size : {}" , readSubMrb);
									for (int subMrbCount = 0; subMrbCount < readSubMrb.size(); subMrbCount++) {
										Map<String, Object> getSubMrbData = readSubMrb.get(subMrbCount);
										seleniumUtility.setTableLookupRowData( "");
										seleniumUtility.setColumnNames( new ArrayList<>());
										for (int m = l; m < attributesList.size(); m++) {
											Transactions subMebTransactions = seleniumController.getORObject().getTransactions().get(1);
											Attributes subMebAttributes = subMebTransactions.getAttributes().get(m);
											int subPid = subMebAttributes.getParentAttrId();
											String subMrebssnew2 = subMebAttributes.getType();
											if (subPid == subsubreb && !subMrebssnew2.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)) {
												seleniumUtility.mrbTransactionDataHandle(subMebAttributes, getSubMrbData,
														subMrbFieldDeatils);
											}
										}
									}
								}
							}
						}

					}

					if (isParent && !seleniumController.getORObject().getTransactions().get(1).getAttributes().get(j).getType()
							.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)) {
						isParent = false;
					}
				}
			}
		}
				// close loop here
	}

	public void dataVerificationfeed(String testdata, List<FieldDetails> fieldIdentifiers, BasicFieldType action,
			String windowOrFrame, boolean clickableInd) throws Exception {
		String windowshandel = null;
		boolean frameFlag = false;
		if (windowOrFrame != null) {
			if (windowOrFrame.startsWith("window")) {
				windowshandel = browserControls.windowsHandeling();
			} else if (windowOrFrame.contains("frame")) {
				frameFlag = true;
				List<FieldDetails> fieldDetail = seleniumController.getFrameMap().get( seleniumController.getFrameAttributeId());
				// -------------------------Need to Rewart code
				pageObjectHandler.frameHandle(fieldDetail);
			}
		}
		if ( !action.equals(BasicFieldType.ALERT)) {
			try {
				pageObjectHandler.findObject(fieldIdentifiers);
				fieldActionVerification(action, testdata);
			} catch (InterruptedException e) {
				logger.error( "Error", e);
			}
		} else {
			if (testdata.contains("|")) {
				String[] alertSplit = testdata.split("\\|");
				pageObjectHandler.applicationPopup(alertSplit[0], alertSplit[1]);
			} else {
				pageObjectHandler.applicationPopup(testdata, "");
			}
		}
		if (windowshandel != null) {
			browserControls.getDriver().switchTo().window(windowshandel);
		}
		if (frameFlag) {
			browserControls.getDriver().switchTo().defaultContent();
		}
	}
	
	private boolean performRadioOrCheckBox( String testData, BasicFieldType type) {
		browserControls.highlightElements(pageObjectHandler.getTransactionElement(), FrameworkConstants.DATA_VERICATION);
		pageObjectHandler.getTransactionElement().isSelected();
		logger.info( "{} : {}  {}", type, pageObjectHandler.getTransactionElement().isSelected(), testData);
		return pageObjectHandler.getTransactionElement().isSelected();
	}

	public void fieldActionVerification(BasicFieldType action, String testData) throws Exception {
		Boolean isPassed = null;
		dvStatus = new HashMap<>();
		browserControls.waitPageloadComplete();
		logger.info("Test Data Verification");
		switch (action) {
			case TEXTBOX:
				browserControls.highlightElements(pageObjectHandler.getTransactionElement(), FrameworkConstants.DATA_VERICATION);
				String attributeValue = pageObjectHandler.getTransactionElement().getAttribute( FrameworkConstants.WEBELEMENT_ATTRIBUTE_VALUE);
				logger.info("Textbox data : {} Textbox   {}", attributeValue ,testData);
				String actualTextValue = pageObjectHandler.getTransactionElement().getAttribute("Value");
				isPassed = actualTextValue.equals(testData);
				break;
			case RADIO:
			case CHECKBOX:
				isPassed = performRadioOrCheckBox( testData, action);
				break;
			case DROPDOWN:
				browserControls.highlightElements(pageObjectHandler.getTransactionElement(), FrameworkConstants.DATA_VERICATION);
				logger.info("Test Data Verification - DropDown");
				Select dropdown = new Select(pageObjectHandler.getTransactionElement());
				logger.info("TrasnactionElement : {}" , pageObjectHandler.getTransactionElement());
				logger.info("Get Drop Down Option");
				dropdown.getFirstSelectedOption();
				logger.info(" {} : {}", dropdown.getFirstSelectedOption().getText(), testData);
				String actualDropDownValue = dropdown.getFirstSelectedOption().getText();
				isPassed = actualDropDownValue.equals(testData);
				break;
			default:
				break;
		}
		if( isPassed != null) {
			logger.info( "{} : status : ", isPassed.booleanValue() ? FrameworkConstants.STATUS_PASS : FrameworkConstants.STATUS_FAIL);
			dvStatus.put( seleniumUtility.getAttributeId(), isPassed.booleanValue() ? FrameworkConstants.STATUS_PASS : FrameworkConstants.STATUS_FAIL);
		}
		for (Entry<Integer, String> entry : dvStatus.entrySet()) {
			logger.info("{} : {}", entry.getKey(), entry.getValue());
			if (entry.getValue().equalsIgnoreCase( FrameworkConstants.STATUS_FAIL)) {
				dvMapPassStatus.put( FrameworkConstants.RESPONSE_VERIFICATION_STATUS, FrameworkConstants.STATUS_FAIL);
				break;
			} else if (entry.getValue().equalsIgnoreCase( FrameworkConstants.STATUS_PASS)) {
				dvMapPassStatus.put( FrameworkConstants.RESPONSE_VERIFICATION_STATUS, FrameworkConstants.STATUS_PASS);
			}
		}  
	}
}
