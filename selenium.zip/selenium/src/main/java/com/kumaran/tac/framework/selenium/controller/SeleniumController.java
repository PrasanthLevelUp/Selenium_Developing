package com.kumaran.tac.framework.selenium.controller;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
//import org.apache.log4j.BasicConfigurator;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kumaran.tac.common.dto.FailureDetail;
import com.kumaran.tac.common.enums.ActionOnValidationFailure;
import com.kumaran.tac.common.exception.RetryStepException;
import com.kumaran.tac.common.exception.TACException;
import com.kumaran.tac.common.util.AutowireHelperUtil;
import com.kumaran.tac.framework.common.client.AgentClient;
import com.kumaran.tac.framework.common.dto.Attributes;
import com.kumaran.tac.framework.common.dto.ExecutionPlan;
import com.kumaran.tac.framework.common.dto.ExpressionResult;
import com.kumaran.tac.framework.common.dto.FieldDetails;
import com.kumaran.tac.framework.common.dto.OrJson;
import com.kumaran.tac.framework.common.dto.TestStep;
import com.kumaran.tac.framework.common.dto.TestStepData;
import com.kumaran.tac.framework.common.dto.Transactions;
import com.kumaran.tac.framework.common.dto.ValidationModel;
import com.kumaran.tac.framework.common.util.FrameworkConstants;
import com.kumaran.tac.framework.common.util.FrameworkUtility;
import com.kumaran.tac.framework.selenium.frameworklayer.BrowserControls;
import com.kumaran.tac.framework.selenium.frameworklayer.PageObjectHandler;
import com.kumaran.tac.framework.selenium.frameworklayer.SeleniumUtility;
import com.kumaran.tac.framework.selenium.frameworklayer.Validations;

@Component
public class SeleniumController {
	private static final Logger logger = LoggerFactory.getLogger(SeleniumController.class);

	@Autowired
	AgentClient agentClient;
	
	@Autowired
	PageObjectHandler pageObjectHandler;
	
	@Autowired
	BrowserControls browserControls;
	
	@Autowired
	SeleniumUtility seleniumUtility;
	
	private Map<Integer, List<Transactions>> transactionDetailMap = new HashMap<>();
	private Map<Integer, ExecutionPlan> executionPlanDetailMap = new HashMap<>();
	private Map<Integer, List<FieldDetails>> frameMap;
	private Map<String,String> variableValues = null;
	private Integer frameAttributeId = 1;
	protected Map<String, Object> validations = null;
	private List<Attributes> attributes = null;
	protected ValidationModel[] entryValidations = null;
	protected ValidationModel[] eoaValidations = null;
	protected ValidationModel[] beforeValidations = null;
	protected ValidationModel[] afterValidations = null;
	protected ValidationModel[] afterReEntryValidations = null;
	private List<Integer> beforePositionIds = null;
	private List<Integer> afterPositionIds = null;
	private Integer multiElement = 0;
	private OrJson oRObject = null;
	private ExecutionPlan exePlan = null;
	private String transactionId = "";
	private List<Map<String, Object>> fieldIdentificationAtrr = null;
	private Integer transactionStepId = null;
	private String transactionName = "";
	private String transactionColumnName = "";
	private String agentUrl = "";
	private Integer mrbpId = 0;
	private String startTime;
	private String completedTime;
	private String mrbGridType;
	private String validationPosition = null;
	private Map<String, Object> testRunDetails;
	private int positionAttributeId;
	private Integer attributeMaxWait=0;
	private String browserControl = null;
	private String stepData = null; 
	private List<String> errorMessages;
	protected List <Attributes> tacPageTitle;
	protected List <Attributes> tacHasAppErrors;
	protected List <Attributes> tacAppErrorMessages;
	protected List <Attributes> tacIsUnhandledError;
	protected List <Attributes> tacUnhandledErrorMessages;
	private boolean continueExecutionOnFailure;
	private FailureDetail failureDetail;
	private Attributes currentAttribute = new Attributes();
	private ObjectMapper objectMapper = new ObjectMapper();
	private Map<String, Map<String, String>> projectLevelTranslations = null;
	private Map<String, Map<String, String>> transactionLevelTranslations = null;
	private String languageTACAUT = "English";
	private String languageVariable = "tac_aut_language";
	private Long reEntryInd;
	private String browser;
	private ActionOnValidationFailure actionOnValidationFailure;

	
	public static void main(String[] args) throws Exception {
		logger.info("Selenium started");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		SeleniumController seleniumController = context.getBean( SeleniumController.class);
		SeleniumUtility seleniumUtility = context.getBean( SeleniumUtility.class);
		AgentClient agentClient = context.getBean( AgentClient.class);
		agentClient.setFrameworkCode( FrameworkConstants.FRAMEWORK_CODE_SELENIUM);
		agentClient.setResourceDir("C:\\agent\\selenium");
		agentClient.loadAgentProperties();
		seleniumController.loadCustomValidationClass( null);
		seleniumController.loadCustomAttributesClass( null);
		seleniumUtility.setApplicationType( "web");
		seleniumController.start();
		agentClient.endRun();
	}
	
	public Map<Integer, List<FieldDetails>> getFrameMap() {
		return frameMap;
	}
	
	public void setFrameMap( Map< Integer, List< FieldDetails>> pFrameMap) {
		frameMap = pFrameMap;
	}
	
	public Map<String, String> getVariableValues() {
		return variableValues;
	}
	
	public void setVariableValues( Map< String, String> pVariablesvalue) {
		variableValues = pVariablesvalue;
	}
	
	public Integer getFrameAttributeId() {
		return frameAttributeId;
	}
	
	public void setFrameAttributeId( Integer id) {
		frameAttributeId = id;
	}
	
	public List<Attributes> getAttributes() {
		return attributes;
	}
	
	public void setAttributesList( List< Attributes> pAttributes) {
		attributes = pAttributes;
	}
	
	public Integer getMultiElement() {
		return multiElement;
	}
	
	public void setMultiElement( Integer element) {
		multiElement = element;
	}
	
	public OrJson getORObject() {
		return oRObject;
	}
	
	public void setORObject( OrJson orObject) {
		oRObject = orObject;
	}
	
	public String getTransactionId() {
		return transactionId;
	}
	
	public void setTransactionId( String id) {
		transactionId = id;
	}
	
	public Integer getTransactionStepId() {
		return transactionStepId;
	}
	
	public void setTransactionStepId( Integer id) {
		transactionStepId = id;
	}
	
	public String getTransactionName() {
		return transactionName;
	}
	
	public void setTransactionName( String name) {
		transactionName = name;
	}
	
	public String getTransactionColumnName() {
		return transactionColumnName;
	}
	
	public void setTransactionColumnName( String name) {
		transactionColumnName = name;
	}
	
	public Integer getMrbpId() {
		return mrbpId;
	}
	
	public void setMrbpId( Integer id) {
		mrbpId = id;
	}
	
	public String getMrbGridType() {
		return mrbGridType;
	}
	
	public void setMrbGridType( String type) {
		mrbGridType = type;
	}
	
	public String getValidationPosition() {
		return validationPosition;
	}
	
	public void setValidationPosition( String position) {
		validationPosition = position;
	}
	
	public int getPositionAttributeId() {
		return positionAttributeId;
	}
	
	public void setPositionAttributeId( int id) {
		positionAttributeId = id;
	}
	
	public Integer getAttributeMaxWait() {
		return attributeMaxWait;
	}
	
	public void setAttributeMaxWait( Integer maxWait) {
		attributeMaxWait = maxWait;
	}
	
	public List< String> getErrorMessages() {
		return errorMessages;
	}
	
	public void setErrorMessages( List< String> messages) {
		errorMessages = messages;
	}
	
	public boolean isContinueExecutionOnFailure() {
		return continueExecutionOnFailure;
	}
	
	public void setContinueExecutionOnFailure( boolean status) {
		continueExecutionOnFailure = status;
	}
	
	public FailureDetail getFailureDetail() {
		return failureDetail;
	}
	
	public void setFailureDetail( FailureDetail detail) {
		failureDetail = detail;
	}
	
	public Attributes getCurrentAttribute() {
		return currentAttribute;
	}
	
	public void setCurrentAttribute( Attributes attributes) {
		currentAttribute = attributes;
	}
	
	public String getTACAUTLanguage() {
		return languageTACAUT;
	}
	
	public void setTACAUTLanguage( String language) {
		languageTACAUT = language;
	}
	
	public void setActionOnFailure( ActionOnValidationFailure action) {
		actionOnValidationFailure = action;
	}
	
	public void loadCustomAttributesClass( String methodName) {
		try {
			Class<?> ca = loadClass( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES);
			if (ca != null) {
				Object objca = ca.newInstance();
				if( methodName != null) {
					Method cam = ca.getMethod( methodName);
					if (cam != null) {
						if( methodName.equals( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_START_TIME)) {
							startTime = (String) cam.invoke(objca);
						} else if( methodName.equals( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_COMPLETED_TIME)) {
							completedTime = (String) cam.invoke(objca);
						}
					}											
				}
			}
		} catch ( Exception e) {
			logger.error( "Exception Error occurred while loading custom attribute class", e.getMessage());
			if( methodName != null) {
				if( methodName.equals( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_START_TIME)) {
					startTime = FrameworkUtility.startTime();					
				} else if( methodName.equals( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_COMPLETED_TIME)) {
					completedTime = FrameworkUtility.completedTime();
				}
			}
		}
	}
	
	private void loadCustomValidationClass( String methodName) {
		try {
			Class<?> ca = loadClass( FrameworkConstants.CLASS_CUSTOM_VALIDATION);
			if (ca != null) {
				Object objcv = ca.newInstance();
				Method cvm = ca.getMethod( methodName);
				if (cvm != null) {
					cvm.invoke(objcv);
				}
			}
		} catch (ClassNotFoundException e) {
			if( methodName != null) {
				Validations validations;
				try {
					validations = AutowireHelperUtil.getBeanObj( Validations.class);
					validations.currentPageValidation();				
				} catch (Exception e1) {
					logger.error( "Error loading Validation object", e1);
				}
			}
		} catch ( Exception e) {
			logger.error( "Error occurred while loading customValidationClass", e);
		}
	}
	
	private Class<?> loadClass( String className) throws ClassNotFoundException   {
		Class<?> classObject = Class.forName( className);
		if (classObject != null) {
			logger.info("CLASS ADDED : {}", className);
		}
		return classObject;
	}
	
	private void start() {
		while (true) {
			try {
				String nextCommand = agentClient.getNextCommandFromAgent();
				logger.info(" [Command] : {}" , (nextCommand != null ? nextCommand.replace( "\n", "") : null));
				if (nextCommand != null) {
					if ( !nextCommand.contains( FrameworkConstants.COMMAND_MESSAGE)) {
						Boolean loopOperation = processTestStepCommand( nextCommand);
						if( loopOperation != null && !loopOperation.booleanValue()) {
							break;
						}
					} else if( nextCommand.contains( FrameworkConstants.COMMAND_MESSAGE)) {
						boolean breakLoop = processMessageCommand( nextCommand);
						if( breakLoop) {
							break;
						}
					}
				} else {
					//Sleep a short time
					Thread.sleep( 250);
				}
			} catch (Exception exception) {
				logger.error("[Exit] Error executing test step.", exception);
				break;
			}
		}
	}
	
	/**
	 * @param nextCommand
	 * @return true : to represent continue; false : to represent break; null : represent no need to continue or break the loop.
	 * @throws Exception
	 */
	private Boolean processTestStepCommand( String nextCommand) throws Exception {
		Boolean isValidToExecute = null;
		ObjectMapper mapper = new ObjectMapper();
		setStepData("");
		TestStep savedAgentDetail = null;
		savedAgentDetail = mapper.readValue(nextCommand, new TypeReference<TestStep>() {});
		oRObject = savedAgentDetail.getOrJson();
		actionOnValidationFailure = ActionOnValidationFailure.DO_NOT_FAIL_TESTCASE; // default action
		isValidToExecute = isValidToExecute( savedAgentDetail);
		if( isValidToExecute != null) {
			return isValidToExecute;
		} 
		extractTestStep( savedAgentDetail);
		TestStepData nextCommandJSON = savedAgentDetail.getTeststepData();
		if (nextCommandJSON == null) {
			logger.error( "[Exit] Exiting the process because no 'Test Step Data' found.");
			isValidToExecute = false;
		} else {
			executeTest(nextCommandJSON);
			Verification verification = AutowireHelperUtil.getBeanObj( Verification.class);
			verification.setDVMapPassStatus( new HashMap<>());
		}
		return isValidToExecute;
	}
	
	private void extractTestStep( TestStep savedAgentDetail) throws Exception {
		transactionId = savedAgentDetail.getTeststepData().getTransactionId().toString();
		Integer tranId = savedAgentDetail.getTeststepData().getTransactionId();
		transactionStepId = savedAgentDetail.getTeststepData().getTestRunStepId();
		if (oRObject.getTransactions() != null) {
			transactionDetailMap.put(tranId, oRObject.getTransactions());
		} else if (transactionDetailMap.containsKey(tranId)) {
			oRObject.setTransactions(transactionDetailMap.get(tranId));
		}
		if (savedAgentDetail.getExecutionPlan() != null
				&& savedAgentDetail.getExecutionPlan().getBrowser() != null) {
			executionPlanDetailMap.put(tranId, savedAgentDetail.getExecutionPlan());
		} else if (executionPlanDetailMap.containsKey(tranId)) {
			savedAgentDetail.setExecutionPlan(executionPlanDetailMap.get(tranId));
		}
		failureDetail = new FailureDetail();
		exePlan = savedAgentDetail.getExecutionPlan();
		browserControl = exePlan.getBrowserControl();
		continueExecutionOnFailure = exePlan.isDoNotFailTestCase();
		seleniumUtility.setApplicationURL( oRObject.getUrl());
		if (oRObject.getBrowser() != null) {
			browser = oRObject.getBrowser();
		}
		testRunDetails = new HashMap<>();
		if (browserControls.getDriver() == null) {
			openBrowserOrAbort();
		}
		printORObjectTransactions();

	}
	
	private Boolean isValidToExecute( TestStep savedAgentDetail) {
		Boolean ret = null;
		if (savedAgentDetail.getWait() != null && !savedAgentDetail.getWait().isEmpty()) {
			logger.debug( "[Wait] Test step contains wait. : {}", savedAgentDetail.getWait());
			ret = true;
		}
		if (savedAgentDetail.getExit() != null && !savedAgentDetail.getExit().isEmpty()) {
			logger.debug( "[Exit] Test step contains Exit. Exiting the process.");
			ret = false;
		}
		if (savedAgentDetail.getAbort() != null && !savedAgentDetail.getAbort().isEmpty()) {
			logger.debug( "[Exit] Test step contains Abort. Exiting the process.");
			if (browserControls.getDriver() != null) {
				browserControls.closeBrowser(browser);
			}
			ret = false;
		}
		return ret;
	}
	
	private void openBrowserOrAbort() throws Exception{
		try {
			browserControls.openBrowser(browser);
		} catch (Exception e) {
			logger.error( "Unable to open browser. Aborting the test run.");
			failureDetail.updateFailureDetails(null, null, "Error occured while invoking the browser", "Browser", null);
			testRunDetails.put( FrameworkConstants.RESPONSE_START_TIME, FrameworkUtility.startTime());
			testRunDetails.put( FrameworkConstants.RESPONSE_TEST_RUN_STEP_ID, transactionStepId.toString());
			populateFinalTestRunDetails( FrameworkConstants.STATUS_ABORTED, failureDetail);
			agentClient.sendTestRunStatus(testRunDetails);
			throw e;
		}
	}
	
	private void printORObjectTransactions() {
		oRObject.getTransactions().forEach(transaction -> {
			List<Attributes> entryList = transaction.getEntry();
			List<Attributes> reEntryList = transaction.getReEntry();
			logger.info("Entry Data - Navigation : ");
			entryList.forEach( e -> logger.info( e.toString()));
			logger.info("ReEntry Data - Navigation : ");
			reEntryList.forEach( e -> logger.info( e.toString()));
			logger.info(reEntryList.toString());
			logger.info(entryList.toString());
		});
	}
	
	private boolean processMessageCommand( String command) throws Exception {
		boolean breakLoop = false;
		if ( command.contains( FrameworkConstants.COMMAND_TEST_RUN_COMPLETED) || command.contains( FrameworkConstants.COMMAND_TEST_RUN_ABORTED)) {
			if (browserControls.getDriver() != null) {
				browserControls.closeBrowser(browser);
			}
			logger.info( "[Exit] Exiting process as Test run completed / Aborted flag triggered.");
			breakLoop = true;
		} else if ( command.contains("testcaseEnd") && browserControl != null && browserControl.equals("tc")) {
			browserControls.closeBrowser(browser);
			Thread.sleep(5000);
			browserControls.setDriver( null);
		}
		return breakLoop;
	}

	public void executeTest(TestStepData testDataJson) throws Exception {
		testRunDetails.put("testRunStepId", testDataJson.getTestRunStepId().toString());
		// ***********************Custom method call *******************
		loadCustomAttributesClass( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_START_TIME);
		testRunDetails.put( FrameworkConstants.RESPONSE_START_TIME, startTime);
		logger.info(  " {} : {}", FrameworkConstants.RESPONSE_START_TIME, startTime);
		try {
			readTestDataFromMaptoAppliaction(testDataJson);
			populateFinalTestRunDetails( FrameworkConstants.STATUS_PASS, null);
		}
		catch (Exception e) {
			boolean testError = false;
			logger.error("Exception :", e);
			if (e.getMessage().equalsIgnoreCase( FrameworkConstants.EXCEPTION_TEST_FAIL)){
				logger.error("Test failed");
			} else if (e.getMessage().equalsIgnoreCase( FrameworkConstants.EXCEPTION_TEST_ERROR)) {
				logger.error("Test Error");
				testError = true;
			} 
			populateFinalTestRunDetails( testError ? FrameworkConstants.STATUS_ERROR: FrameworkConstants.STATUS_FAIL, failureDetail);
		}
		agentClient.sendTestRunStatus(testRunDetails);
	}
	
	private void populateFinalTestRunDetails( String status, FailureDetail failureDetail) {
		loadCustomAttributesClass( FrameworkConstants.CLASS_CUSTOM_ATTRIBUTES_METHOD_COMPLETED_TIME);
	
		try {
			Verification verification = AutowireHelperUtil.getBeanObj( Verification.class);
			logger.info("DataVerification Value Now : {}" , verification.getDataVerification());
			if (verification.getDataVerification() != null && !verification.getDVMapPassStatus().isEmpty()) {
				testRunDetails.put( FrameworkConstants.RESPONSE_VERIFICATION_STATUS,
						verification.getDVMapPassStatus().get( FrameworkConstants.RESPONSE_VERIFICATION_STATUS).toString());
			}
		} catch (Exception e) {
			logger.error("Error getting instnace of Verification", e);
		}
		if( actionOnValidationFailure != null) {
			testRunDetails.put( FrameworkConstants.RESPONSE_ACTION_ON_FAILURE, actionOnValidationFailure);
		}
		testRunDetails.put( FrameworkConstants.RESPONSE_STATUS, status);
		testRunDetails.put( FrameworkConstants.RESPONSE_COMPLETED_TIME, completedTime);
		testRunDetails.put( FrameworkConstants.RESPONSE_TEST_RUN_EXECUTION_ID, exePlan.getTestRunExecutionId());
		if( failureDetail != null) {
			testRunDetails.put( FrameworkConstants.RESPONSE_FAILURE_REASON, failureDetail);			
		}
		testRunDetails.put( FrameworkConstants.RESPONSE_STEP_DATA, getStepData());
	}
	
	private void compareTitles( String title, String actualTitle, boolean isPartialTitle) {
		String failureMessage = "title("+title+") does not match- "+actualTitle;
		if( ( isPartialTitle && !actualTitle.contains(title)) ||  !actualTitle.equals(title)) {
			logger.error( "{} {}", isPartialTitle ? "Partial" :"" , failureMessage);
			failureDetail.updateFailureDetails(null, null, failureMessage, FrameworkConstants.MESSAGE_CODE_STANDARD, 
					transactionStepId);
			if(!continueExecutionOnFailure){									
				throw new TACException( FrameworkConstants.EXCEPTION_TEST_FAIL);
			}
		}
	}
	
	private ValidationModel[] extractValidationsAndIds( String position, List< Integer> ids)
			throws JacksonException {
		ObjectMapper mapper = new ObjectMapper();
		ValidationModel[] validationModels = null;
		try {
			validationModels = mapper.readValue(mapper.writeValueAsString( validations.get( position)),ValidationModel[].class);
			ids.clear();
			ids.addAll( Arrays.asList( validationModels).stream().map( ValidationModel::getPositionAttributeId).collect( Collectors.toList()));
		} catch (NullPointerException e) {
			validationModels = null;
		}
		return validationModels;
	}
	
	private void performValidation( String position, int i, ValidationModel[] validationModels, Integer attributeId) throws Exception {
		if( attributeId != null) {
			positionAttributeId= attributeId;			
		}
		validationPosition = position;
		Validations validations = AutowireHelperUtil.getBeanObj( Validations.class);
		validations.validationStart(validationModels, oRObject, i);
		validationPosition = null;
		if( attributeId != null) {
			positionAttributeId = 0;			
		}
		if( !actionOnValidationFailure.equals( ActionOnValidationFailure.DO_NOT_FAIL_TESTCASE)) {
			String attributeName = "";
			int id = 0;
			if( !position.equals(FrameworkConstants.VALIDATION_POSITION_ENTRY)) {
				attributeName = getCurrentAttribute() != null ? getCurrentAttribute().getName() : "";
				id = getCurrentAttribute() != null ? getCurrentAttribute().getId() : 0;				
			}
			failureDetail.updateFailureDetails( id, attributeName, "Validation Status failed", FrameworkConstants.MESSAGE_CODE_VALIDATION, transactionStepId);
			if( !continueExecutionOnFailure){
				throw new TACException( FrameworkConstants.EXCEPTION_TEST_FAIL);
			}
		}
	}

	/**
	 * @param testDataJson
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void readTestDataFromMaptoAppliaction(TestStepData testDataJson) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		List<Map<String, Object>> readMrbFromMap = new ArrayList<>();
		List<Transactions> transactionList = oRObject.getTransactions();
		actionOnValidationFailure = ActionOnValidationFailure.DO_NOT_FAIL_TESTCASE; // default next action
		frameMap = new HashMap<>();
		transactionStepId = testDataJson.getStepId();
		transactionId = testDataJson.getTransactionId().toString();
		fieldIdentificationAtrr = testDataJson.getFieldIdentificationAtrr();
		reEntryInd = testDataJson.getReEntryInd();
		transactionColumnName = "";
		variableValues =  testDataJson.getVariables();
		if(variableValues.containsKey(languageVariable) && variableValues.get(languageVariable) != null) {
			languageTACAUT = variableValues.get(languageVariable);
		}
		loadCustomValidationClass(  FrameworkConstants.CLASS_CUSTOM_VALIDATION_METHOD_CURRENT_PAGE_VALIDATION);
			try {
				
			Validations validationHelper = AutowireHelperUtil.getBeanObj( Validations.class);
			validationHelper.currentPageValidation();
	
			List<Map<String, Object>> arrtibuteJson = testDataJson.getAttributeTestData();
			int testDataSize = arrtibuteJson.size();
	
			Transactionloop: for (int i = 0; i < transactionList.size(); i++) {
	
				Transactions transaction = transactionList.get(i);
				projectLevelTranslations = transaction.getProjectLevelTranslations();
				transactionLevelTranslations = transaction.getTransactionLevelTranslations();
				formStandardAttributes(transaction);
				attributes = transaction.getAttributes();
				int orTransctionId = transaction.getTransactionId();
	
				/************** Entry code for the Each transaction ***************/
	
				if (orTransctionId == Integer.valueOf(transactionId)) {
					List<Attributes> entry = transaction.getEntry();
					Map<String, Object> attributeJson = null;
					logger.info("Transaction entry size : {}" , entry.size());
					if ( !entry.isEmpty()) {
						logger.info("Entry attribute id {}" , entry.get(0).getId());
						for (int j = 0; j < entry.size(); j++) {
							logger.info("Post Validation  Entry");
							Attributes entryAttr = entry.get(j);
							attributeMaxWait = entryAttr.getMaxWait();
							attributeJson = arrtibuteJson.get(0);
							Integer attributeId = entryAttr.getId();
							String testData = attributeJson.get(String.valueOf(attributeId)) == null ? ""
									: attributeJson.get(String.valueOf(attributeId)).toString();
							try {							
								pageObjectHandler.dataFeed(testData, entryAttr, entryAttr.getWindowOrFrame());
							} catch(StaleElementReferenceException e) {
								pageObjectHandler.dataFeed(testData, entryAttr, entryAttr.getWindowOrFrame());
							}
							attributeMaxWait = 0;
						}
					}
	
					for (int a = 0; a < testDataSize; a++) {
						Map<String, Object> singleTestDataJsonObject = arrtibuteJson.get(a);
	
						try {
							validations = (Map<String, Object>) singleTestDataJsonObject.get("validations");
						} catch (NullPointerException e) {
							validations = null;
						} 
	
						transactionName = transaction.getTransactionName();
						boolean isParent = false;
						logger.info("Browser title : {}", browserControls.getDriver().getTitle());
						if (transaction.getPageTitle() != null && !transaction.getPageTitle().isEmpty()) {
							String title = transaction.getPageTitle();
							String actualTitle = null;
							for(Attributes attribute : tacPageTitle) {
								WebElement webElement = null;
								try {								
									webElement = pageObjectHandler.findObject(attribute.getFieldDetails());
								} catch(Exception e) {
									continue;
								}
								actualTitle = webElement.getText();
							}
							if(tacPageTitle.isEmpty() || actualTitle == null) {							
								actualTitle = browserControls.getDriver().getTitle();
							}
							compareTitles(title, actualTitle, transaction.getPartialTitleInd() == 1);
						}
						
						builtInValidations(transaction);
						
						if(validations!=null) {
							try{ 
								entryValidations = mapper.readValue(mapper.writeValueAsString(validations.get(FrameworkConstants.VALIDATION_POSITION_ENTRY)),
										ValidationModel[].class);
								performValidation( FrameworkConstants.VALIDATION_POSITION_ENTRY, i, entryValidations, null);
							} catch( NullPointerException e){							
								entryValidations = null;	
							}
						}
						
						if(validations!=null) {
							beforePositionIds = beforePositionIds == null ? new ArrayList<>() : beforePositionIds;
							afterPositionIds = afterPositionIds == null ? new ArrayList<>() : afterPositionIds;
							beforeValidations = extractValidationsAndIds( FrameworkConstants.VALIDATION_POSITION_BEFORE, beforePositionIds);
							afterValidations = extractValidationsAndIds( FrameworkConstants.VALIDATION_POSITION_AFTER, afterPositionIds);
							try {
								eoaValidations = mapper.readValue(mapper.writeValueAsString(validations
										.get( FrameworkConstants.VALIDATION_POSITION_END_OF_ATTRIBUTE)),ValidationModel[].class);
							} catch(NullPointerException e){
								eoaValidations = null;
							}
						} else {
							beforeValidations = null;
							afterValidations = null;
							entryValidations = null;
							afterReEntryValidations = null;
							eoaValidations = null;
						}
						
						if ( actionOnValidationFailure.equals( ActionOnValidationFailure.DO_NOT_FAIL_TESTCASE)) {
							for (int j = 0; j < attributes.size(); j++) {
								Attributes attrs = this.attributes.get(j);
								currentAttribute = this.attributes.get(j);
								attributeMaxWait = attrs.getMaxWait();
								if( attrs.getRead_only() != null && attrs.getRead_only() == 1) {
									continue;
								}
								int attributeId = attrs.getId();
								int parentAttributeId = attrs.getParentAttrId();
								if(beforeValidations != null && beforePositionIds.contains(attributeId)){
									performValidation( FrameworkConstants.VALIDATION_POSITION_BEFORE, i, beforeValidations, attributeId);
								}
								String mrbgrid = attrs.getType();
								if (mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME)) {
									frameMap.put(Integer.valueOf(attributeId), attrs.getFieldDetails());
								}
								if (parentAttributeId == 0 && !mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID) && !isParent
										&& !mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME) 
										&& !mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_WINDOW_DIALOG)) {
									seleniumUtility.transactionDataHandle(attrs, singleTestDataJsonObject);
								}
								if (parentAttributeId == 0 && attrs.getType().equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)
										|| attrs.getType().equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME)
										|| attrs.getType().equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_WINDOW_DIALOG) && !isParent) {
									attributeId =attrs.getId();
									readMrbFromMap = (List<Map<String, Object>>) singleTestDataJsonObject.get(String.valueOf(attributeId));
									logger.info("MRB content : {}", readMrbFromMap.toString());
									isParent = true;
									List<FieldDetails> mrbFieldDeatils = attrs.getFieldDetails();
									for (int mrbcount = 0; mrbcount < readMrbFromMap.size(); mrbcount++) {
										Map<String, Object> readListOfMrbs = readMrbFromMap.get(mrbcount);
										seleniumUtility.setTableLookupRowData( "");
										seleniumUtility.setColumnNames( new ArrayList<>());
										for (int l = j; l < this.attributes.size(); l++) {
											Attributes mrbAttributes = this.attributes.get(l);
											mrbpId = mrbAttributes.getParentAttrId();
											String subMrebssNew = mrbAttributes.getType();
											mrbGridType = attrs.getGridType();
											if (mrbpId == attributeId && mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_WINDOW_DIALOG)) {
												seleniumUtility.mrbTransactionDataHandle(mrbAttributes, readListOfMrbs, mrbFieldDeatils);
											}
											if (mrbpId == attributeId && mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_FRAME)) {
												seleniumUtility.mrbTransactionDataHandle(mrbAttributes, readListOfMrbs, mrbFieldDeatils);
											}
											if (mrbpId == attributeId && mrbgrid.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)
													&& !subMrebssNew.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)) {
												seleniumUtility.mrbTransactionDataHandle(mrbAttributes, readListOfMrbs, mrbFieldDeatils);
											} else if (mrbpId == attributeId && subMrebssNew.equalsIgnoreCase("grid")) {
												int subsubreb = mrbAttributes.getId();
												List<FieldDetails> subMrbFieldDeatils = mrbAttributes.getFieldDetails();
												List<Map<String, Object>> readSubMrb = (List<Map<String, Object>>) readListOfMrbs
														.get(String.valueOf(subsubreb));
												logger.info("Sub mrabs data size : {}" , readSubMrb);
												for (int subMrbCount = 0; subMrbCount < readSubMrb.size(); subMrbCount++) {
													Map<String, Object> getSubMrbData = readSubMrb.get(subMrbCount);
													seleniumUtility.setTableLookupRowData( "");
													seleniumUtility.setColumnNames( new ArrayList<>());
													for (int m = l; m < this.attributes.size(); m++) {
														Transactions subMebTransactions = oRObject.getTransactions().get(i);
														Attributes subMebAttributes = subMebTransactions.getAttributes()
																.get(m);
														int subPid = subMebAttributes.getParentAttrId();
														String subMrebssnew2 = subMebAttributes.getType();
														if (subPid == subsubreb
																&& !subMrebssnew2.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)) {
															seleniumUtility.mrbTransactionDataHandle(subMebAttributes, getSubMrbData, subMrbFieldDeatils);
														}
													}
												}
											}
										}
									}
								}
								if ( isParent && !oRObject.getTransactions().get(i).getAttributes().get(j).getType()
										.equalsIgnoreCase( FrameworkConstants.CONTAINER_ELEMENT_GRID)) {
									isParent = false;
									continue;
								}
								builtInValidations(transaction);
								if( afterValidations != null && afterPositionIds.contains(attributeId)){
									performValidation( FrameworkConstants.VALIDATION_POSITION_AFTER, i, afterValidations, attributeId);
								}
								if((( attrs.getEndTransactionFlag() != null && attrs.getEndTransactionFlag().booleanValue())
										|| attributes.size() == j+1) && eoaValidations != null) {
									performValidation( FrameworkConstants.VALIDATION_POSITION_END_OF_ATTRIBUTE, i, eoaValidations, null);
								}
								
								if( !errorMessages.isEmpty()) {
									failureDetail.updateFailureDetails(currentAttribute.getId(), 
											currentAttribute.getName(), 
											"application error occured- "+objectMapper.writeValueAsString(errorMessages), 
											FrameworkConstants.MESSAGE_CODE_STANDARD, transactionStepId);
									if(!continueExecutionOnFailure){
										throw new TACException( FrameworkConstants.EXCEPTION_TEST_FAIL);
									}
								}
								if( ( attrs.getEndTransactionFlag() != null && attrs.getEndTransactionFlag().booleanValue())
										|| attributes.size() != j+1) {
									builtInValidations(transaction);
								}
							}
							attributeMaxWait = 0;
							try {
								logger.info("Post Validation Re Entry");
								List<Attributes> reentry = null;
								if(reEntryInd.intValue()==1) {
									reentry = transaction.getEntry();
								} else {								
									reentry = transaction.getReEntry();
								}
								logger.info("Reentry validation size : {}" , reentry.size());
								if ( !reentry.isEmpty()) {
	//								for (int j = 0; j < reentry.size(); j++) {
	//									logger.info("Post Validation Re Entry");
	//									Attributes reEntryAttr = reentry.get(j);
	//
	//									logger.info("Post Validation Re Entry");
	//									attributeMaxWait = reEntryAttr.getMaxWait();
	//									attributeJson = arrtibuteJson.get(0);
	//									Integer attributeId = reEntryAttr.getId();
	//									String testData = attributeJson.get(String.valueOf(attributeId)) == null ? ""
	//											: attributeJson.get(String.valueOf(attributeId)).toString();
	//									try {										
	//										pageObjectHandler.datafeed(testData, reEntryAttr, reEntryAttr.getWindowOrFrame());
	//									} catch(StaleElementReferenceException e) {
	//										Selenide.refresh();
	//										pageObjectHandler.datafeed(testData, reEntryAttr, reEntryAttr.getWindowOrFrame());
	//									}
	//									attributeMaxWait = 0;
	//								}
	//								Verification.DataVerificationFromMaptoAppliaction(testDataJson, i);
									Verification verification = AutowireHelperUtil.getBeanObj( Verification.class);
									verification.setDataVerification( "");
								}
							} catch (Exception e) {
								logger.error( "Error occurred : " , e);
								if(e.getMessage().equals( FrameworkConstants.EXCEPTION_TEST_FAIL)) {
									throw e;
								}
							}
	
							if (validations != null) {
								try{
									afterReEntryValidations = mapper.readValue(validations
											.get( FrameworkConstants.VALIDATION_POSITION_AFTER_REENTRY).toString(),ValidationModel[].class);
									performValidation( FrameworkConstants.VALIDATION_POSITION_AFTER_REENTRY, i, afterReEntryValidations, null);
								} catch (NullPointerException e){
									afterReEntryValidations = null;
								}
							}
							/********************
							 * Below Entry code copied to make the Entry from next
							 * transaction
							 ***********************/
							if (a == testDataSize - 1) {
								break Transactionloop;
							}
						}
					}
				}
			}
		} catch( RetryStepException e) {
			readTestDataFromMaptoAppliaction(testDataJson);
		}
	}

	public void builtInValidations(Transactions transaction) {
		errorMessages = new ArrayList<>();
		if ( !tacHasAppErrors.isEmpty()) {			
			gatherErrorMessages(tacHasAppErrors);
		}
		if ( !tacAppErrorMessages.isEmpty()) {					
			gatherErrorMessages(tacAppErrorMessages);
		}
		if ( !tacIsUnhandledError.isEmpty()) {					
			gatherErrorMessages(tacIsUnhandledError);
		}
		if ( !tacUnhandledErrorMessages.isEmpty()) {					
			gatherErrorMessages(tacUnhandledErrorMessages);
		}
	}

	private void gatherErrorMessages(List<Attributes> attributeList) {
		for( Attributes attr :attributeList) {
			if(attr.getEnabledInd() == 1) {
				List<WebElement> elementList = pageObjectHandler.findAllObjects(attr.getFieldDetails());
				elementList.stream().filter( Objects::nonNull).map( WebElement::getText).filter( Objects::nonNull)
					.filter( ((Predicate<String>) String::isEmpty).negate()).forEach( errorMsg -> errorMessages.add(errorMsg));
			}
		}
	}
	
	public void formStandardAttributes(Transactions transaction) {
		tacPageTitle = new ArrayList<>();
		tacHasAppErrors = new ArrayList<>();
		tacAppErrorMessages = new ArrayList<>();
		tacIsUnhandledError = new ArrayList<>();
		tacUnhandledErrorMessages = new ArrayList<>();
		processStandardAttributes( transaction.getTransactionLevelStandardAttributes(), false);
		processStandardAttributes( transaction.getProjectLevelStandardAttributes(), true);
	}
	
	private void processStandardAttributes( List< Attributes> attributes, boolean isProjectLevel) {
		for(Attributes obj: attributes) {
			if (obj.getName().equals( FrameworkConstants.TAC_PAGE_TITLE) && ( !isProjectLevel || tacPageTitle.isEmpty())) {
				tacPageTitle.add(obj);
			} else if (obj.getName().equals( FrameworkConstants.TAC_HAS_APP_ERRORS) && ( !isProjectLevel || tacHasAppErrors.isEmpty())) {
				tacHasAppErrors.add(obj);
			} else if (obj.getName().equals( FrameworkConstants.TAC_APP_ERROR_MESSAGES) && ( !isProjectLevel || tacAppErrorMessages.isEmpty())) {
				tacAppErrorMessages.add(obj);
			} else if (obj.getName().equals( FrameworkConstants.TAC_IS_UNHANDLED_ERROR) && ( !isProjectLevel || tacIsUnhandledError.isEmpty())) {
				tacIsUnhandledError.add(obj);
			} else if (obj.getName().equals( FrameworkConstants.TAC_UNHANDLED_ERROR_MESSAGES) && ( !isProjectLevel || 
					tacUnhandledErrorMessages.isEmpty())) {
				tacUnhandledErrorMessages.add(obj);
			}
		}
	}
	
	public String translateTestData( String testData) {
		String tempData = null;
		if(transactionLevelTranslations != null && transactionLevelTranslations.containsKey(languageTACAUT)){
			tempData = getTranslatedValue(testData,transactionLevelTranslations.get(languageTACAUT));
			if(tempData != null) {
				return tempData;
			}
		} 
		if (projectLevelTranslations != null && projectLevelTranslations.containsKey(languageTACAUT)) {
			tempData = getTranslatedValue(testData,projectLevelTranslations.get(languageTACAUT));
			if(tempData != null) {
				return tempData;
			}
		}
		return testData;
	}
	
	public String getTranslatedValue(String testData, Map<String, String> translation) {
		if(translation.containsKey(testData)) {
			return translation.get(testData);
		}
		return null;
	}
	
	public String getFieldIdentificationAtrrVal(Integer attributeId) {
		String idValue = null;
		if(fieldIdentificationAtrr != null && !fieldIdentificationAtrr.isEmpty()) {
			Optional< String> optional = fieldIdentificationAtrr.stream().filter( e -> e.containsKey( attributeId.toString()))
					.map( e -> e.get( attributeId.toString()).toString()).findFirst();
			if( optional.isPresent()) {
				idValue = optional.get();
				if(idValue.contains("$")) {
					 ExpressionResult expRes = agentClient.getExpressionValue(idValue);
					 idValue = expRes.getOutput();
					 if( expRes.hasError()) {
						 pageObjectHandler.setFailureReason( expRes.getErrorMessage());
					 }
				}
			}
		}
		return idValue; 
	}

	public String getStepData() {
		return stepData;
	}

	public void setStepData(String stepData) {
		this.stepData = stepData;
	}
	
}
