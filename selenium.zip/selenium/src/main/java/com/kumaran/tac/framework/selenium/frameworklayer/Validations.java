package com.kumaran.tac.framework.selenium.frameworklayer;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kumaran.tac.common.enums.ActionOnValidationFailure;
import com.kumaran.tac.common.enums.RetryAction;
import com.kumaran.tac.common.enums.ValidationType;
import com.kumaran.tac.common.exception.RetryStepException;
import com.kumaran.tac.common.exception.TACException;
import com.kumaran.tac.framework.common.client.AgentClient;
import com.kumaran.tac.framework.common.dto.Attributes;
import com.kumaran.tac.framework.common.dto.FieldDetails;
import com.kumaran.tac.framework.common.dto.OrJson;
import com.kumaran.tac.framework.common.dto.Transactions;
import com.kumaran.tac.framework.common.dto.ValidationModel;
import com.kumaran.tac.framework.common.util.FrameworkConstants;
import com.kumaran.tac.framework.selenium.controller.SeleniumController;

@Component
public class Validations  {

	@Autowired
	AgentClient agentClient;
	
	@Autowired
	SeleniumController seleniumController;

	@Autowired
	PageObjectHandler pageObjectHandler;
	
	@Autowired
	BrowserControls browserControls;
	
	private String controlName = "";
	private String type="";
	private String expectedValue = "";
	private String boundaryStart = "";
	private String boundaryEnd = "";
	private String rowNumber = "";
	private String contentInRow = "";
	private String columnHeading = "";
	private String uniqueRowdata = "";
	private String variableKey = null;
	private String statusofValidations;
//	private boolean doNotFailtestCase = false;
	private int fieldIgnoreInd;
	private Document doc1 = null;
	private String htmltext = null;
//	public HashMap<String, Object> validatiionDetails = new HashMap<String, Object>();
	private int validationId = 0;
	private List<HashMap<Object, Object>> validations;
	private Map<Object, Object> validationStatus;
	private Map<String, Object> validationStatusMap = new HashMap<>();
	private final Logger mainLogger = LoggerFactory.getLogger(Validations.class);
	private String actualValue;
//	public String comparisonType;
	private String objectVisiblevalue;
	private String objecteditvalue;
	private String validationStatusId;
	private int validationLinkId;
	private String statusValidation; 
	private String comparisonMethod;
	private Map<String, Object> validationObjMap = null;
	private JSONParser parser1 = new JSONParser();
	private JSONObject statusofValidation01;
	private ObjectMapper objectMapper = new ObjectMapper();
	private ValidationModel validationData = null;
	
	public void validationStart(ValidationModel[] validationModelData, OrJson oRObject, int i) throws Exception {
		for (int val = 0; val < validationModelData.length; val++) {
			validationData = validationModelData[val];
			int valKey = validationData.getAttributeId();
			comparisonMethod = validationData.getConditionExpression();
			ValidationType validationType = ValidationType.getValidationType(validationData.getValidationType());
			controlName = validationData.getControlName();	
			expectedValue = validationData.getExpectedValue();
			boundaryStart = validationData.getBoundaryStart();
			boundaryEnd = validationData.getBoundaryEnd();
			rowNumber = validationData.getRowNumber();
			contentInRow = validationData.getContentInRow();
			columnHeading = validationData.getColumnHeading();
			uniqueRowdata = validationData.getUniqueRowData();
			variableKey = validationData.getVariableName();
			type=validationData.getType();
			Transactions transctions = oRObject.getTransactions().get(i);
			List<Attributes> attributesList = transctions.getAttributes();
			if( seleniumController.getPositionAttributeId() !=  validationData.getPositionAttributeId() && 
					(seleniumController.getValidationPosition().equals( FrameworkConstants.VALIDATION_POSITION_BEFORE) 
							|| seleniumController.getValidationPosition().equals( FrameworkConstants.VALIDATION_POSITION_AFTER))){
				continue;
			}
			boolean retryValidation = false;
			for (int j = 0; j < attributesList.size(); j = retryValidation ? j : j+1) {
				retryValidation = false;
				Attributes attribute = attributesList.get(j);
				validationId = attribute.getId();
				validationStatusId = validationData.getValidationId();
				validationLinkId = validationData.getValidationLinkId();
				fieldIgnoreInd=attribute.getIgnore_ind();
//				doNotFailtestCase = ActionOnValidationFailure.DO_NOT_FAIL_TESTCASE
//						.equals( ActionOnValidationFailure.get( validationData.getActionOnFailure()));
				String mrbgrid = attribute.getType();
				List<FieldDetails> fieldIdentifiers = attribute.getFieldDetails();
				String windowOrFrame = attribute.getWindowOrFrame();
				seleniumController.setFrameAttributeId( attribute.getFrameAttrId());
				mainLogger.info("Validation Type : {} " , validationType);
				if (mrbgrid.equalsIgnoreCase(FrameworkConstants.CONTAINER_ELEMENT_FRAME)) {
					seleniumController.getFrameMap().put(Integer.valueOf(validationId), attribute.getFieldDetails());
				}
				statusofValidations = null; 
				if (validationType.equals(ValidationType.POPUPMESSAGE) || validationType.equals(ValidationType.ALERT) 
						|| validationType.equals(ValidationType.DETERMINELANGUAGE) || validationType.equals(ValidationType.ERRORMESSAGE)){					
					validationDetails(fieldIdentifiers, validationType, comparisonMethod, windowOrFrame, mrbgrid);
					statusofValidation01 = (JSONObject) parser1.parse(statusValidation);
					mainLogger.info("Status of validation : {}" , statusofValidation01);
					statusofValidations = statusofValidation01.get("status").toString();
					final String LANGUAGE_KEY = "language"; 
					if(statusofValidation01.containsKey( LANGUAGE_KEY)){
						seleniumController.setTACAUTLanguage( statusofValidation01.get( LANGUAGE_KEY).toString());
						seleniumController.getVariableValues().put("tac_aut_language", statusofValidation01.get( LANGUAGE_KEY).toString());
						mainLogger.error("Language : {} ", statusofValidation01.get( LANGUAGE_KEY));
					}
//					if (statusofValidations.equalsIgnoreCase( FrameworkConstants.STATUS_PASS)){
//						mainLogger.info("Validation - {} : Pass. Moving to Next Validation or Transaction Activity", validationType);
//					}
//					else if (statusofValidations.equalsIgnoreCase( FrameworkConstants.STATUS_FAIL)){
//						mainLogger.info("Validation - {} : Fail. Skipped the Validation or Transaction Activity", validationType);
//					}
//					break;
				} else if (valKey == validationId) {
					mainLogger.info("Validation Type : {}", validationType);
					validationDetails(fieldIdentifiers, validationType, comparisonMethod, windowOrFrame, mrbgrid);
					mainLogger.info("Status Validation : {}", statusValidation);
					statusofValidation01 = (JSONObject) parser1.parse(statusValidation);
					mainLogger.info("Status of Validation : {}" , statusofValidation01);
					statusofValidations = statusofValidation01.get( FrameworkConstants.RESPONSE_STATUS).toString();
				}
				if( statusofValidations != null) {
					if (statusofValidations.equalsIgnoreCase( FrameworkConstants.STATUS_PASS)){
						mainLogger.info("Validation - {} : Pass. Moving to Next Validation or Transaction Activity", validationType);
					}
					else if (statusofValidations.equalsIgnoreCase( FrameworkConstants.STATUS_FAIL)){
						mainLogger.info("Validation - {} : Fail. Skipped the Validation or Transaction Activity", validationType);
						RetryAction retryAction = RetryAction.get( ( String)statusofValidation01.get( FrameworkConstants.RETRY_ACTION));
						if( retryAction == null) {
							mainLogger.debug( "No retry action provided by agent for validationLinkId : {}", validationLinkId);
							break;						
						} else {
							if( retryAction.equals( RetryAction.VALIDATION)) {
								mainLogger.info( "[Retry] Retrying {} validation once again. ValidationLinkId : {}", validationType,
										validationLinkId);
								retryValidation = true;
							} else if( retryAction.equals( RetryAction.STEP)) {
								mainLogger.info( "[Retry] Retrying step once again. Caused by validationLinkId : {}", validationLinkId);
								throw new RetryStepException( "Retrying step");
							} else {
								throw new TACException( "Unknown retry action : "+ retryAction);
							}
						}
					}
				}
			}
		}
		ActionOnValidationFailure action = agentClient.getNextActionAfterValidation();
		if( action != null) {
//			if( !action.equals( ActionOnValidationFailure.DO_NOT_FAIL_TESTCASE)) {
//				seleniumController.setValidationStatusInd( 0);
//			} else {
//				seleniumController.setValidationStatusInd( 1);
//			}
			seleniumController.setActionOnFailure( action);
			mainLogger.info( "Next action after {} validation : {}", seleniumController.getValidationPosition(), action);
		} else {
			seleniumController.setActionOnFailure( ActionOnValidationFailure.FAIL_TESTCASE);
			mainLogger.error( "Next action after validation was not received from agent. Failing the testcase.");
		}
	}

	public void validationDetails( List<FieldDetails> fieldIdentifiers, ValidationType validationType,
			String comparisonMethod, String windowOrFrame, String fieldType) throws Exception {
	    validations = new ArrayList<>();
		validationStatus = new HashMap<>();
		String windowshandle = null;
		boolean frameFlag = false;
		if (windowOrFrame != null) {
			if (windowOrFrame.startsWith("window")) {
				windowshandle = browserControls.windowsHandeling();
			} else if (windowOrFrame.contains("frame")) {
				frameFlag = true;
				List<FieldDetails> fieldDetail = seleniumController.getFrameMap().get(seleniumController.getFrameAttributeId());
				pageObjectHandler.frameHandle(fieldDetail);
			}
		}
		WebElement element =null;
		if (!validationType.equals(ValidationType.ALERT) && !validationType.equals(ValidationType.ERRORMESSAGE) && !validationType.equals(ValidationType.DETERMINELANGUAGE)){
			element= pageObjectHandler.findObject(fieldIdentifiers);
		} else if (validationType.equals(ValidationType.ERRORMESSAGE)) {
			pageObjectHandler.findAllObjects(fieldIdentifiers);
		}
		
		switch (validationType) {
			case CONTENT:
				contentValidation(element, expectedValue, fieldType);
				break;
			case EDITABILITY:
				controlEditability(element);
	 			break;
			case VISIBILITY:
			    objectVisibiltyValidation(element);
				break;
	//		case VALIDATIONMESSAGE:
	//			MessageValidation(expectedValue);
	//			break;
			case POPUPMESSAGE:	
				popupMessageValidation(expectedValue);
				break;
			case TOOLTIPMESSAGE:
				toolTipMessageValidation(element, expectedValue);
				break;
			case ALERT:
				alertTextValidation(expectedValue);
				break;
			case TABLE:
				tableValidation(fieldIdentifiers);
				break;
			case TEXT:
				textValidation(element, Integer.parseInt(boundaryStart), Integer.parseInt(boundaryEnd), expectedValue);
				break;
			case DETERMINELANGUAGE:
				determineLanguageValidation(expectedValue);
				break;	
			case ERRORMESSAGE:
				errorMessageValidation();
				break;	
			default:
				try {
					
					comparisonMethod=comparisonMethod==null? "":comparisonMethod;
					Object[] obj = {element,expectedValue,fieldType,comparisonMethod,validationType};// for method1()
				    Class<?> params[] = new Class[obj.length];
			        for (int i = 0; i < obj.length; i++) {
			            if (obj[i] instanceof Integer) {
			                params[i] = Integer.TYPE;
			            } else if (obj[i] instanceof String) {
			                params[i] = String.class;
			            }else if (obj[i] instanceof WebElement) {
			                params[i] = WebElement.class;
			            }
			        }
					Class<?> custVal = Class.forName("Custom_Validation");
					if(custVal!=null) {
						 Object objCustom = custVal.newInstance();
						 Method customVal =  custVal.getMethod("CustomValidationMethod",params);
						 if(customVal!=null){
							 customVal.invoke(objCustom,obj); 
						 }
					 }
				} catch (InstantiationException e) {
					mainLogger.error( "Error in validationDetails", e);
				} catch (IllegalAccessException e1) {
					mainLogger.error( "Error in validationDetails", e1);
				} catch (NoSuchMethodException e2) {
					mainLogger.error( "Error in validationDetails", e2);
				} catch (SecurityException e3) {
					mainLogger.error( "Error in validationDetails", e3);
				} catch (ClassNotFoundException e4) {
					mainLogger.error( "Error in validationDetails", e4);
				} catch (IllegalArgumentException e5) {
					mainLogger.error( "Error in validationDetails", e5);
				} catch (InvocationTargetException e6) {
					mainLogger.error( "Error in validationDetails", e6);
				}
			break;	
		}
		if (windowshandle != null) {
			browserControls.getDriver().switchTo().window(windowshandle);
		}
		if (frameFlag) {
			browserControls.getDriver().switchTo().defaultContent();
		}
	}

	public void objectVisibiltyValidation(WebElement ele) throws JsonProcessingException {
		Map<String, Object> validationDetails = null;
		comparisonMethod = FrameworkConstants.COMPARISION_METHOD_EQUALS;
		if (ele != null) {
			objectVisiblevalue = ele.isDisplayed() ? "Visible" : "Not-Visible";
		} else {
			objectVisiblevalue = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		if (variableKey != null) {
			seleniumController.getVariableValues().put(variableKey, objectVisiblevalue);
		}
		validationDetails = addCommonKeys(objectVisiblevalue);
		statusValidation = agentClient.validationActualStatus(validationDetails);
	}
	
	public void controlEditability(WebElement ele) throws JsonProcessingException  {		
		Map<String, Object> validationDetails = null;
		comparisonMethod = FrameworkConstants.COMPARISION_METHOD_EQUALS;
		if (ele != null) {
			objecteditvalue = !ele.isEnabled() ? "NonEditable" : "Editable";
		} else {
			objecteditvalue = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		if (variableKey != null) {
			seleniumController.getVariableValues().put(variableKey, objecteditvalue);
		}
		validationDetails = addCommonKeys(objecteditvalue);
		statusValidation = agentClient.validationActualStatus(validationDetails);
	}
	
	public void contentValidation(WebElement element, String expectedValue, String fieldType) throws JsonProcessingException {
		Map<String, Object> validationDetails = null;
		String transactionElementValue = null;
		if(element != null) {
			switch (fieldType.toLowerCase()) {
				case "textbox":
					transactionElementValue = getValueForContentValidation(element, false);
					break;
				case "dropdown":
					Select select = new Select(element);
					WebElement option = select.getFirstSelectedOption();
					transactionElementValue = getValueForContentValidation(option, true);
					break;
				default:
					transactionElementValue = getValueForContentValidation(element, true);
					break;
			}
		} else if(fieldIgnoreInd == 1) {
			transactionElementValue = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		if(variableKey != null){			
			seleniumController.getVariableValues().put(variableKey,transactionElementValue);
		}
		validationDetails = addCommonKeys(transactionElementValue);
		validationDetails.put("TAC_AUT_LANGUAGE", seleniumController.getTACAUTLanguage());
		statusValidation = agentClient.validationActualStatus(validationDetails);
	}
	
	public void toolTipMessageValidation(WebElement ele, String expectedText) throws JsonProcessingException {
		Map<String, Object> validationDetails = null;
		comparisonMethod = FrameworkConstants.COMPARISION_METHOD_EQUALS;	
		String actual = null;
		if(ele != null) {			
			String actualTitle = ele.getAttribute("title");
			String actualDataTitle=ele.getAttribute("data-original-title");
			if(actualTitle.equals("") && !actualTitle.equals(expectedText)) {
				actual = actualDataTitle;
			} else {
				actual = actualTitle;
			}
		} else if(fieldIgnoreInd == 1) {
			actual = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		validationDetails = addCommonKeys(actual);
		if(variableKey != null){			
			seleniumController.getVariableValues().put(variableKey,actual);
		}
        statusValidation = agentClient.validationActualStatus(validationDetails);
        /*return actual;
		returnValidationData.add(toolTipMessage);
        Actions actions = new Actions(browserControls.driver);
		actions.moveToElement(TrasnactionElement).perform();*/
	}

	public void alertTextValidation(String expectedAlertText) throws JsonProcessingException {
		comparisonMethod = FrameworkConstants.COMPARISION_METHOD_EQUALS;
		String alertActualValue = browserControls.getDriver().switchTo().alert().getText();
		Map<String, Object> validationDetails = addCommonKeys(alertActualValue);
		browserControls.getDriver().switchTo().alert().accept();
		if(variableKey != null){			
			seleniumController.getVariableValues().put(variableKey,alertActualValue);		
		}
		statusValidation = agentClient.validationActualStatus(validationDetails);
	}

	@SuppressWarnings("rawtypes")
	public void currentPageValidation() {
		String value = null;
		Map<String, Object> currentPageValidation = seleniumController.getORObject().getProjectValidation();
		Iterator validatorItr = currentPageValidation.entrySet().iterator();
		while (validatorItr.hasNext()) {
			Map.Entry validationPair = (Map.Entry) validatorItr.next();
			value = validationPair.getValue().toString();
			try {
				browserControls.getDriver().getPageSource();
				doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
			} catch (UnhandledAlertException e) {
				doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
			}
			catch (NullPointerException e) {
				mainLogger.error("Null in Page source : {}", e.getMessage());
			}
			htmltext = doc1.select("html").text();
			mainLogger.info( "Status : {} ", htmltext.contains(value) ? "Fail" : "Pass");
		}
	}

	public void tableValidation( List<FieldDetails> fieldIdentifiers) throws Exception {
		WebElement table = pageObjectHandler.findObject(fieldIdentifiers);
		List<WebElement> tr = table.findElements(By.tagName("tr"));
		Map<String, Object> validationDetails = addCommonKeys(null);
		validationDetails.put("column_heading", columnHeading);
		int rownum = 0;
		int columPos = 0;
		
		try {
			rownum = Integer.valueOf(rowNumber);
		} catch (NumberFormatException e) {
			// Ignoring exception.
		}
		StringBuilder nameBuilder = new StringBuilder();
		if (!columnHeading.contains(",")) {
			List<WebElement> th = tr.get(0).findElements(By.tagName("th"));
			for (int i = 0; i < th.size(); i++) {
				String columName = th.get(i).getText();
				nameBuilder.append( th.get(i).getText());
				if (columnHeading.equalsIgnoreCase(columName)) {
					columPos = i;
					break;

				}

			}
			if (!nameBuilder.toString().contains(columnHeading)) {
				mainLogger.info("Column not present");
			}
		} 
//		else if (!columnHeading.contains(",")) {
//			if ( nameBuilder.toString().contains(columnHeading)) {
//				mainLogger.info("Column heading is present");
//			} else {
//				mainLogger.info("Column heading not present");
//			}
//		}
		if (rownum > 0) {
			List<WebElement> td = tr.get(rownum).findElements(By.tagName("td"));
			String actColumnData = td.get(columPos).getText();
			validationDetails.put("actColumnData", actColumnData);
		}
		statusValidation = agentClient.validationActualStatus(validationDetails);
	}

	

	public void popupMessageValidation(String expectedValue) throws JsonProcessingException {
		try {
			doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
		} catch (UnhandledAlertException e) {
			doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
		}
		htmltext = doc1.select("html").text();
		comparisonMethod = FrameworkConstants.COMPARISION_METHOD_CONTAINS;
		Map<String, Object> validationDetails = addCommonKeys(htmltext); 
        if(variableKey != null){			
			seleniumController.getVariableValues().put(variableKey,htmltext);
		}
        statusValidation = agentClient.validationActualStatus(validationDetails);
	}

	/*public void ObjectDisabledValidation(WebElement ele) throws Exception {
		HashMap<String, Object> objectDisabledValidation = new HashMap<String, Object>();
		
		objectDisabledValidation.put("ValidationPosition", seleniumController.ValidationPosition);
		objectDisabledValidation.put("transactionId", seleniumController.transactionId);
		objectDisabledValidation.put("validationStatusId", validationStatusId);
		objectDisabledValidation.put("validationLinkId", validationLinkId);
		Boolean currentStatus = ele.isEnabled();
		if(currentStatus!=true) {
			objecteditvalue = "NonEditable";
			objectDisabledValidation.put("value", objecteditvalue); }
		else {
			objecteditvalue = "Editable";
			objectDisabledValidation.put("value", objecteditvalue); }
	
		comparisonType = "Equals";
		objectDisabledValidation.put("comparisonType", comparisonType);
		StatusValidation = seleniumController.validationActualStatus(objectDisabledValidation);
	}*/


	public boolean alert() {
		try {
			WebDriverWait wait = new WebDriverWait(browserControls.getDriver(), 3);
			wait.until(ExpectedConditions.alertIsPresent());
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void textValidation(WebElement text, int boundaryStart, int boundaryEnd, String expectedValue) throws JsonProcessingException {
		Map<String, Object> validationDetails = null; 
		comparisonMethod = FrameworkConstants.COMPARISION_METHOD_EQUALS;
		if(text != null){
			String actualText;
			actualText= text.getText().trim();
			if(actualText.equals("")) {
				actualText = text.getAttribute("value").trim();				 	
			}
			try {
				actualValue = actualText.substring(boundaryStart-1, boundaryEnd);
			} catch(Exception e){
				seleniumController.getFailureDetail().setMessage("Validation Type:Text-"+e.getMessage());
				seleniumController.getFailureDetail().setMessageCode("Validation");
			} 
		} else if(fieldIgnoreInd == 1) {
			actualValue = FrameworkConstants.MESSAGE_ELEMENT_NOT_FOUND;
		}
		if(variableKey != null){			
			seleniumController.getVariableValues().put(variableKey,actualValue);
		}
		validationDetails = addCommonKeys(actualValue);
		statusValidation = agentClient.validationActualStatus(validationDetails);
	}

	public void messageValidation(String expectedValue) throws JsonProcessingException {
		Map<String, Object> validationDetails = null; 
		try {
			doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
		} catch (UnhandledAlertException e) {
			doc1 = Jsoup.parse(browserControls.getDriver().getPageSource());
		}
		htmltext = doc1.select("html").text();
		comparisonMethod = FrameworkConstants.COMPARISION_METHOD_CONTAINS;
		validationDetails = addCommonKeys(htmltext);
        if(variableKey != null){			
			seleniumController.getVariableValues().put(variableKey,htmltext);
		}
        statusValidation = agentClient.validationActualStatus(validationDetails);
	}
	
	public void determineLanguageValidation(String expectedValue) {
		JSONParser parser = new JSONParser();
		Map<String, String> actualValMap = new HashMap<>();
		try {
			JSONArray customArray = (JSONArray) parser.parse(expectedValue);
			JSONObject obj = null;
			List<Integer> attrId = new ArrayList<>();
			int attributeId = 0;
			for (int i = 0; i < customArray.size(); i++) {
				obj = (JSONObject) customArray.get(i);
				attributeId = Integer.parseInt(obj.get("attributeId").toString());
				if (!attrId.contains(attributeId)) {
					loop: for (Attributes attr : seleniumController.getAttributes()) {
						if (attr.getId() == attributeId) {
							WebElement element = pageObjectHandler.findObject(attr.getFieldDetails());
							String val = null;
							if (element != null) {
								switch (attr.getType().toUpperCase()) {
								case "BUTTON":
								case "LINK":
								case "label":

									val = element.getText();
									if (val != null) {
										actualValMap.put(attr.getName(), val);
									}
									break loop;
								case "TEXTBOX":
								case "RADIO":
								case "CHECKBOX":
								case "IMAGE":
									val = element.getAttribute("value");
									if (val != null) {
										actualValMap.put(attr.getName(), val);
									}
									break loop;
								case "DROPDOWN":
									Select select = new Select(element);
									WebElement option = select.getFirstSelectedOption();
									val = option.getText();
									if (val != null) {
										actualValMap.put(attr.getName(), val);
									}
									break loop;
								default:
									val = element.getText();
									if (val != null && !val.isEmpty()) {
										actualValMap.put(attr.getName(), val);
									}
									break loop;
								}
							}
						}
					}
					attrId.add(attributeId);
				}
			}
			comparisonMethod = FrameworkConstants.COMPARISION_METHOD_IN;
			Map<String, Object> validationDetails = addCommonKeys(objectMapper.writeValueAsString(actualValMap));
			statusValidation = agentClient.validationActualStatus(validationDetails);
			mainLogger.info("Status validation : {}", statusValidation);
		} catch (Exception e) {
			mainLogger.error("Error", e);
		}
	}
	public void errorMessageValidation() {
		try {
			String val = objectMapper.writeValueAsString(seleniumController.getErrorMessages());
			Map<String, Object> validationDetails = addCommonKeys(val);
			statusValidation = agentClient.validationActualStatus(validationDetails);
			Map<String, Object> status = objectMapper.readValue(statusValidation,HashMap.class);
			if( status.containsKey("failureReason")) {
				String residualErrorMsgs = objectMapper.writeValueAsString(status.get("failureReason"));
				try {
					seleniumController.setErrorMessages( objectMapper.readValue(residualErrorMsgs, new TypeReference<ArrayList<String>>() {}));
				} catch(Exception e) {
					seleniumController.setErrorMessages( new ArrayList<>());
				}
			} else {
				seleniumController.setErrorMessages( new ArrayList<>());
			}
		} catch (Exception e) {
			mainLogger.error("Error executing errorMessageValidation ", e);
			throw new TACException(e);
		}
	}
	
	public Map<String, Object> addCommonKeys(Object actualValObject) {
		Map<String, Object>	validationDetails = new HashMap<>();
		validationDetails.put("ValidationPosition", seleniumController.getValidationPosition());
		validationDetails.put("transactionId", seleniumController.getTransactionId());
		validationDetails.put("validationLinkId", validationLinkId);
		validationDetails.put("validationStatusId", validationStatusId);
		validationDetails.put("comparisonType", comparisonMethod);
		validationDetails.put("value", actualValObject);
		if( validationData != null && validationData.getRetry() != null && !validationData.getRetry().isEmpty()) {
			validationDetails.putAll( validationData.getRetry());
		}
		if( validationData != null && validationData.getActionOnFailure() != null) {
			validationDetails.put( "actionOnValidationFailure", validationData.getActionOnFailure());
		}
		return validationDetails;
	}
	
	public String getValueForContentValidation(WebElement ele, boolean getTextInd) {
		String source = validationData.getSource() != null ? validationData.getSource() : "value";
		String value = null;
		switch (source) {
		case "style":
			return ele.getCssValue(validationData.getStyle());
		case "class":
			return ele.getAttribute(source);
		case "value":
		case "length":
			return getTextInd ? ele.getText() : ele.getAttribute("value");		
		case "attribute":
			return ele.getAttribute(validationData.getAttribute().toString());
	
		default:
			break;
		}
		return value;
	}
}
