package com.kumaran.tac.framework.selenium.frameworklayer;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kumaran.tac.common.enums.Browser;
import com.kumaran.tac.common.enums.OperatingSystem;
import com.kumaran.tac.common.util.CommonUtility;
import com.kumaran.tac.framework.common.client.AgentClient;
import com.kumaran.tac.framework.common.util.FrameworkConstants;
import com.kumaran.tac.framework.selenium.controller.SeleniumController;
import com.microsoft.edge.seleniumtools.EdgeDriver;
import com.microsoft.edge.seleniumtools.EdgeOptions;

@Component
public class BrowserControls {
	@Autowired
	AgentClient agentClient;

	@Autowired
	SeleniumController seleniumController;

	@Autowired
	SeleniumUtility seleniumUtility;
	
	private WebDriver driver = null;
	private String extention ="";
	private Actions action = null;
	public final Logger mainLogger = LoggerFactory.getLogger(BrowserControls.class);
	
	public WebDriver getDriver() {
		return driver;
	}
	
	public void setDriver( WebDriver webDriver) {
		driver = webDriver;
	}
	
	public Actions getAction() {
		return action;
	}
	
	public void setAction( Actions actions) {
		action = actions;
	}
	
	// Open Different type of browser
	public void openBrowser(String browserName) throws IOException {
		// get current project path
		OperatingSystem os = CommonUtility.getOperatingSystem();
		mainLogger.info( "Current operating system : {}", os);
		if (seleniumUtility.getApplicationType().equalsIgnoreCase("WEB")) {
			if( os.equals( OperatingSystem.WINDOWS)) {
				extention = ".exe";
			} else {
				extention = "";
			}
			//Debugging purpose code//
			Browser browser = Browser.getBrowser(browserName);
			mainLogger.info("BrowserName : {}" , browserName);
			switch (browser) {
				case IE:
					seleniumUtility.setApplicationBrowserExePath( agentClient.getResourceDir()+"/IEDriverServer"+extention);
					mainLogger.info("IE DRIVER: {}" , seleniumUtility.getApplicationBrowserExePath());
					System.setProperty("webdriver.ie.driver", seleniumUtility.getApplicationBrowserExePath());
					InternetExplorerOptions capab = new InternetExplorerOptions();
					capab.setCapability("handlesAlerts", true);
					capab.setCapability("ignoreZoomSetting", true);
					capab.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
					capab.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
					capab.setCapability("requireWindowFocus", true);
					capab.setCapability("enablePersistentHover", false);
					capab.setCapability("nativeEvents", true);
					driver = new InternetExplorerDriver(capab);
					driver.findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, "0"));
					driver.manage().window().setSize(new Dimension(1280, 1024));
					break;
				case CHROME:
					seleniumUtility.setApplicationBrowserExePath( agentClient.getResourceDir()+"/chromedriver"+extention);
					mainLogger.info("CHROME DRIVER: {}" , seleniumUtility.getApplicationBrowserExePath());
					System.setProperty("webdriver.chrome.driver", seleniumUtility.getApplicationBrowserExePath());
					ChromeOptions chromecap = new ChromeOptions();
					chromecap.setCapability("handlesAlerts", false);
					driver = new ChromeDriver(chromecap);
					//driver.manage().window().maximize();
					break;
				case EDGE:
					seleniumUtility.setApplicationBrowserExePath( agentClient.getResourceDir()+"/msedgedriver"+extention);
					mainLogger.info("EDGE DRIVER: {}" , seleniumUtility.getApplicationBrowserExePath());
					System.setProperty("webdriver.edge.driver", seleniumUtility.getApplicationBrowserExePath());
					EdgeOptions edgeOptions = new EdgeOptions();
					edgeOptions.setCapability( EdgeOptions.USE_CHROMIUM, true);
					edgeOptions.setCapability("handlesAlerts", false);
					driver = new EdgeDriver(edgeOptions);
					break;
				case FIREFOX:
					seleniumUtility.setApplicationBrowserExePath( agentClient.getResourceDir()+"/geckodriver"+extention);
					mainLogger.info("FIREFOX DRIVER: {}" , seleniumUtility.getApplicationBrowserExePath());
					System.setProperty("webdriver.gecko.driver", seleniumUtility.getApplicationBrowserExePath());
					FirefoxOptions fireFoxCap = new FirefoxOptions();
					fireFoxCap.setCapability("handlesAlerts", false);
					driver = new FirefoxDriver(fireFoxCap);
					break;
				default:
					try {
						Object[] obj = { browserName };// for method1()
						Class<?> params[] = new Class[obj.length];
						for (int i = 0; i < obj.length; i++) {
							if (obj[i] instanceof Integer) {
								params[i] = Integer.TYPE;
							} else if (obj[i] instanceof String) {
								params[i] = String.class;
							} else if (obj[i] instanceof WebElement) {
								params[i] = WebElement.class;
							}
						}
						Class<?> fa = Class.forName("Custom_Attributes");
						if (fa != null) {
							mainLogger.info("class added");
							Object objfa = fa.newInstance();
							Method fam = fa.getMethod("CustomBrowser", params);
							if (fam != null) {
								mainLogger.info("class added 2");
								fam.invoke(objfa, obj);
							}
						}
					} catch (InstantiationException e) {
						mainLogger.error( "Error in openBrowser", e);
					} catch (IllegalAccessException e1) {
						mainLogger.error( "Error in openBrowser", e1);
					} catch (NoSuchMethodException e2) {
						mainLogger.error( "Error in openBrowser", e2);
					} catch (SecurityException e3) {
						mainLogger.error( "Error in openBrowser", e3);
					} catch (ClassNotFoundException e4) {
						mainLogger.error( "Error in openBrowser", e4);
					} catch (IllegalArgumentException e5) {
						mainLogger.error( "Error in openBrowser", e5);
					} catch (InvocationTargetException e6) {
						mainLogger.error( "Error in openBrowser", e6);
					}
					break;
			}
			if( driver != null) {
				driver.manage().window().maximize();
				driver.get(seleniumUtility.getApplicationURL());
			}
		}
		action = new Actions(driver);
	}

	// Close Different type of browser
	public void closeBrowser(String browserName){
		Browser browser = Browser.getBrowser( browserName);
		if ( browser != Browser.FIREFOX ) {
			driver.close();
		}
		driver.quit();
		try {
			switch( browser) {
				case IE:
					Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
					Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
					break;
				case CHROME:
					Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
					break;			
				case EDGE:
					Runtime.getRuntime().exec("taskkill /F /IM msedgedriver.exe");
					break;
				default : 
					mainLogger.warn( "Unable to terminate the driver for browser : {}", browser);
			}
		} catch (IOException e) {
			mainLogger.error( "Error", e);
		}
	}
	
	// hightLight the object in Webpage
	public void highlightElements(WebElement element, String actionColor) {
		String color = "";
		if (actionColor.equalsIgnoreCase("feed") || actionColor.equalsIgnoreCase("Pass")) {
			color = "blue";
		} else if (actionColor.equalsIgnoreCase("Fail")) {
			color = "red";
		} else if (actionColor.equalsIgnoreCase("Table")) {
			color = "yellow";
		} else if (actionColor.equalsIgnoreCase("Verification")) {
			color = "green";
		}
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='2px solid " + color + "'", element);
		}
	}

	// wait Untill pageLoding Completed
	public boolean waitPageloadComplete() {
		try {
			ExpectedCondition<Boolean> expectation = e -> ((JavascriptExecutor) driver).executeScript("return document.readyState")
					.equals("complete");
			Integer timeOut = 0;
			if(seleniumController.getAttributeMaxWait() !=null ){
				timeOut = seleniumController.getAttributeMaxWait();
			}else{
				timeOut = 40;
			}
			Wait<WebDriver> wait = new WebDriverWait( driver, timeOut);
			wait.until(expectation);
			return true;
		} catch (Exception e) {
			mainLogger.info(e.getMessage());
		}
		return false;

	}

	// Explicit wait for 45 sec till object to be found
	public void explicitWaitForObjectFoundBy(By by) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		}catch (ElementNotVisibleException e) {
			seleniumController.getFailureDetail().setMessage( FrameworkConstants.MESSAGE_ELEMENT_NOT_VISIBLE);
			seleniumController.getFailureDetail().setMessageCode( FrameworkConstants.MESSAGE_CODE_NOT_FOUND);
		} catch (Exception e) {
			mainLogger.error( "Exception occurred : {}", e.getMessage());
		}

	}

	public void explicitWaitForObjectFound(WebElement element) {
		try {
			Integer timeOut =0;
			if(seleniumController.getAttributeMaxWait() != null && seleniumController.getAttributeMaxWait() != 0){
				timeOut = seleniumController.getAttributeMaxWait();
			}else {
				timeOut = 45;
			}
			WebDriverWait wait = new WebDriverWait(driver, timeOut);
			wait.until(ExpectedConditions.visibilityOf(element));
		}catch (TimeoutException e){
			seleniumController.getFailureDetail().setMessage( FrameworkConstants.MESSAGE_TIMEOUT_ELEMENT_NOT_VISIBLE);
			seleniumController.getFailureDetail().setMessageCode( FrameworkConstants.MESSAGE_CODE_TIMEOUT);
			throw new TimeoutException();
		}
		catch (ElementNotVisibleException e) {
			seleniumController.getFailureDetail().setMessage( FrameworkConstants.MESSAGE_ELEMENT_NOT_VISIBLE);
			seleniumController.getFailureDetail().setMessageCode( FrameworkConstants.MESSAGE_CODE_NOT_FOUND);
			throw new ElementNotVisibleException( FrameworkConstants.MESSAGE_ELEMENT_NOT_VISIBLE);
		}
	}


	public String multipleWindowsHandeling(String windowPos) {
		int i = 1;
		int switchWindow = Integer.parseInt(windowPos);
		String parentwinow = driver.getWindowHandle();
		Set<String> allWindow = driver.getWindowHandles();
		for (String window : allWindow) {
			if (switchWindow == i) {
				driver.switchTo().window(window);
				break;
			}
			i++;
		}
		return parentwinow;
	}

	// Switch to one window to another window
	public String windowsHandeling() {
		String parentwinow = driver.getWindowHandle();
		Set<String> allWindow = driver.getWindowHandles();
		while ( !allWindow.isEmpty()) {
			for (String window : allWindow) {
				if (!parentwinow.equalsIgnoreCase(window)) {
					driver.switchTo().window(window);
					break;
				}
			}
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				mainLogger.error( "Error", e);
			}
			if (allWindow.size() > 1) {
				break;
			}
			allWindow = driver.getWindowHandles();
		}
		mainLogger.info("Window size : {}", allWindow.size());
		return parentwinow;
	}
}
